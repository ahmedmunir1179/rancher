# Docker — Fundamentals (Docker Hub + Compose + Dockerfile)

This README walks you through **Docker basics** including working with **Docker Hub (online)**, **Docker Compose**, and authoring a **Dockerfile**. It’s designed to be copy-paste friendly.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Install & Quick Check](#install--quick-check)
3. [Core Image & Container Commands](#core-image--container-commands)
4. [Volumes (Persist Data)](#volumes-persist-data)
5. [Networks (Service-to-Service)](#networks-service-to-service)
6. [Write a Dockerfile](#write-a-dockerfile)
7. [Build, Tag, and Run Images](#build-tag-and-run-images)
8. [Docker Compose (multi-service)](#docker-compose-multi-service)
9. [Use Docker Hub (Login / Push / Pull)](#use-docker-hub-login--push--pull)
10. [Multi-Stage & Production Tips](#multi-stage--production-tips)
11. [Troubleshooting](#troubleshooting)
12. [Daily Workflow Cheat Sheet](#daily-workflow-cheat-sheet)

---

## Prerequisites

* **Docker Desktop** (macOS/Windows) or **Docker Engine** (Linux)
* **Docker Compose v2** (bundled with Docker Desktop; `docker compose` command)
* **Docker Hub account** *(optional, only needed to push to hub)*

---

## Install & Quick Check

```bash
# Verify Docker Engine
docker --version

# Verify Compose v2
docker compose version

# Run a quick container (prints hello then exits)
docker run --rm hello-world
```

---

## Core Image & Container Commands

```bash
# Search and pull images
docker search nginx
docker pull nginx:latest

# Run a container (daemonized) mapping host port 8080 -> container 80
docker run -d --name web -p 8080:80 nginx:latest

# List running / all containers
docker ps
docker ps -a

# Container logs & shell access
docker logs -f web
docker exec -it web sh     # or bash, depending on image

# Stop / remove containers
docker stop web
docker rm web

# List images / remove image
docker images
docker rmi nginx:latest

# Clean up dangling stuff (use with care)
docker system df
docker system prune -f
```

---

## Volumes (Persist Data)

```bash
# Create a named volume
docker volume create appdata
docker volume ls

# Use the volume (maps to /var/lib/mysql inside container)
docker run -d --name db -v appdata:/var/lib/mysql mysql:8

# Bind mount a local folder (good for dev)
mkdir -p $(pwd)/site
docker run -d --name web \
  -p 8080:80 \
  -v $(pwd)/site:/usr/share/nginx/html:ro \
  nginx:latest
```

**When to use what?**

* **Named volumes**: portable, managed by Docker, great for production data.
* **Bind mounts**: live-editing source code from your host during development.

---

## Networks (Service-to-Service)

```bash
# Create a user-defined bridge network
docker network create appnet
docker network ls

# Attach services to it
docker run -d --name redis --network appnet redis:7
docker run -d --name api --network appnet myorg/api:1.0

# Containers on the same network can resolve each other by name:
# e.g., from 'api' container use hostname 'redis' to connect to Redis.
```

---

## Write a Dockerfile

Create `Dockerfile` (simple Python API example):

```dockerfile
# syntax=docker/dockerfile:1
FROM python:3.12-slim

# Set workdir
WORKDIR /app

# Install deps (leverage layer caching)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy the app
COPY . .

# Non-root user (recommended)
RUN useradd -m appuser
USER appuser

# Expose and run
EXPOSE 8000
CMD ["python", "app.py"]
```

Create `.dockerignore` to keep images slim:

```
__pycache__/
*.pyc
*.pyo
*.pyd
.env
.git
.gitignore
node_modules
dist
build
```

---

## Build, Tag, and Run Images

```bash
# Build image and tag it
docker build -t myuser/myapp:0.1.0 .

# Run it (map host port 8000 -> container 8000)
docker run -d --name myapp -p 8000:8000 myuser/myapp:0.1.0

# Tail logs
docker logs -f myapp

# Inspect and exec
docker inspect myapp | less
docker exec -it myapp sh
```

**Multi-arch builds (optional):**

```bash
# Enable buildx (often pre-configured with Docker Desktop)
docker buildx ls
docker buildx build --platform linux/amd64,linux/arm64 \
  -t myuser/myapp:0.1.0 --push .
```

---

## Docker Compose (multi-service)

Create `compose.yaml`:

```yaml
name: mystack
services:
  web:
    image: nginx:latest
    ports:
      - "8080:80"
    volumes:
      - ./site:/usr/share/nginx/html:ro
    depends_on:
      - api

  api:
    build:
      context: .
      dockerfile: Dockerfile
    environment:
      - DB_HOST=db
      - DB_USER=myuser
      - DB_PASS=mypass
    ports:
      - "8000:8000"
    develop:
      watch:
        - action: sync
          path: .
          target: /app
          ignore:
            - .git/
            - __pycache__/

  db:
    image: postgres:16
    environment:
      - POSTGRES_PASSWORD=secret
      - POSTGRES_DB=appdb
    volumes:
      - dbdata:/var/lib/postgresql/data

volumes:
  dbdata:
```

Common Compose commands:

```bash
# Start in background
docker compose up -d

# View logs / specific service logs
docker compose logs -f
docker compose logs -f api

# List, stop, restart
docker compose ps
docker compose restart api
docker compose down             # stop + remove containers
docker compose down -v          # also remove volumes (CAUTION)
```

**Compose tips**

* Put secrets in `.env` (Compose auto-loads it).
* Use **profiles** to toggle services for dev/prod.
* Healthchecks: ensure dependencies are ready before app starts.

---

## Use Docker Hub (Login / Push / Pull)

```bash
# Login (stores credentials locally)
docker login

# Tag image for your hub namespace
docker tag myuser/myapp:0.1.0 myuser/myapp:latest

# Push to Docker Hub
docker push myuser/myapp:0.1.0
docker push myuser/myapp:latest

# Pull from Docker Hub (any machine)
docker pull myuser/myapp:latest
docker run -d -p 8000:8000 myuser/myapp:latest
```

**Private repos:**
Create a private repo on Docker Hub → `docker login` → `docker pull myuser/privateapp:tag` (authorized users only).

---

## Multi-Stage & Production Tips

**Multi-stage build (smaller images):**

```dockerfile
# Builder stage
FROM python:3.12-slim AS builder
WORKDIR /app
COPY requirements.txt .
RUN pip wheel --no-cache-dir -r requirements.txt -w /wheels
COPY . .

# Final stage
FROM python:3.12-slim
WORKDIR /app
COPY --from=builder /wheels /wheels
RUN pip install --no-cache-dir /wheels/* && rm -rf /wheels
COPY --from=builder /app .
USER 10001
EXPOSE 8000
CMD ["python", "app.py"]
```

**General best practices**

* Pin versions (base image & deps).
* Use non-root users.
* Keep images small (`alpine`/`-slim` where appropriate).
* Add healthchecks (Compose or `HEALTHCHECK` in Dockerfile).
* Scan images: `docker scout quickview` *(if available)* or other scanners.

---

## Troubleshooting

* **Port in use**: change host port mapping, e.g., `-p 8081:80`.
* **File permissions**: when bind-mounting on Linux, align UID/GID or use `:z` for SELinux.
* **DNS/Networking**: containers on the same **user-defined network** resolve by service/container name.
* **“exec format error” on ARM vs AMD**: build with `buildx --platform` or pull a compatible image tag.
* **Cache bloat**: `docker system prune -af --volumes` *(destructive; double-check first!)*.

---

## Daily Workflow Cheat Sheet

```bash
# 1) Start services
docker compose up -d

# 2) Inspect logs / iterate
docker compose logs -f api
docker compose exec api sh

# 3) Rebuild after code changes
docker compose build api
docker compose up -d api

# 4) Tag & push to Docker Hub
docker tag myuser/myapp:0.2.0 myuser/myapp:latest
docker push myuser/myapp:0.2.0
docker push myuser/myapp:latest

# 5) Pull & run on another machine
docker pull myuser/myapp:latest
docker run -d -p 8000:8000 myuser/myapp:latest

# 6) Clean up
docker compose down
docker system prune -f
```

---

### You’re set!

You now have a practical, step-by-step **Docker fundamentals** guide covering **Docker Hub**, **Compose**, and **Dockerfile** essentials.
