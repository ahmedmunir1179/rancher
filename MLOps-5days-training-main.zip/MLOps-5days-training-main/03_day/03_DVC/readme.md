# DVC + Python (with `uv`) — Fundamentals (Local / LAN Only)

This README walks you through **Data Version Control (DVC)** basics using the **`uv` Python package manager**. Everything is set up to work **offline** or on your **local network (LAN)**—no cloud storage required.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Project Setup (Git + uv)](#project-setup-git--uv)
3. [Install DVC (with SSH support)](#install-dvc-with-ssh-support)
4. [Initialize DVC & Cache](#initialize-dvc--cache)
5. [Track Data with `dvc add`](#track-data-with-dvc-add)
6. [Configure Local/LAN Remote Storage](#configure-locallan-remote-storage)
7. [Push/Pull Data](#pushpull-data)
8. [Build Reproducible Pipelines (`dvc stage add`, `dvc repro`)](#build-reproducible-pipelines-dvc-stage-add-dvc-repro)
9. [Metrics & Params (Optional but Useful)](#metrics--params-optional-but-useful)
10. [Experiments (Optional)](#experiments-optional)
11. [Garbage Collection & Cleaning Up](#garbage-collection--cleaning-up)
12. [Daily Workflow Cheat Sheet](#daily-workflow-cheat-sheet)
13. [Troubleshooting (Local/LAN setups)](#troubleshooting-locallan-setups)

---

## Prerequisites

* **Git** installed (`git --version`)
* **uv** installed (fast Python package manager)

  * Install instructions: [https://docs.astral.sh/uv/](https://docs.astral.sh/uv/) (or your preferred method)
* A **local folder** for DVC “remote” storage **or** an **SSH-accessible machine** on your LAN

> We’ll keep everything on your machine or your LAN—**no cloud providers**.

---

## Project Setup (Git + uv)

```bash
# 1) Create a new repo
mkdir my-dvc-project && cd my-dvc-project
git init

# 2) Create a Python virtual environment with uv
uv venv  # creates .venv in the project

# 3) (Optional) If you need a specific Python version managed by uv:
# uv python install 3.11
# uv venv --python 3.11

# Tip: You can run commands inside the venv WITHOUT activating it:
# uv run <command>
```

> You can activate the venv if you prefer:
>
> * macOS/Linux: `source .venv/bin/activate`
> * Windows (PowerShell): `.venv\Scripts\Activate.ps1`

---

## Install DVC (with SSH support)

We’ll install DVC with SSH extras so we can use an **SSH remote on your LAN** if needed.

```bash
uv pip install "dvc[ssh]"
```

Verify:

```bash
uv run dvc --version
```

---

## Initialize DVC & Cache

```bash
# Initialize DVC in this repo
uv run dvc init

# (Recommended) Make DVC links efficient on local disks
uv run dvc config cache.type "hardlink,symlink"

# Commit DVC config (tracked by Git)
git add .dvc .gitignore
git commit -m "Initialize DVC"
```

> DVC keeps file content in `.dvc/cache/` and uses links in your workspace for speed and space efficiency.

---

## Track Data with `dvc add`

```bash
# Put raw data in a folder
mkdir -p data
# (copy your files into data/, e.g., data/raw.csv)

# Track large files with DVC (not Git)
uv run dvc add data/raw.csv
# or entire folder:
# uv run dvc add data/

# Commit DVC metadata (NOT the big files)
git add data/raw.csv.dvc .gitignore
git commit -m "Track raw dataset with DVC"
```

> `dvc add` creates a small `.dvc` file that Git will track; the heavy data stays in the DVC cache/remote.

---

## Configure Local/LAN Remote Storage

Choose **one** of the two options below:

### Option A — Local folder remote (same machine or mounted drive)

```bash
# Example local path OUTSIDE the repo (good practice)
mkdir -p /srv/dvcstore

uv run dvc remote add -d localstore /srv/dvcstore
git add .dvc/config
git commit -m "Add local DVC remote (localstore)"
```

### Option B — LAN SSH remote (another machine on your network)

```bash
# Replace user, host, and path with your LAN SSH details
uv run dvc remote add -d lan ssh://user@192.168.1.50:/data/dvcstore

# Use key-based auth (recommended)
uv run dvc remote modify lan keyfile ~/.ssh/id_ed25519
uv run dvc remote modify lan ask_password false

git add .dvc/config
git commit -m "Add LAN SSH DVC remote (lan)"
```

> We’re intentionally avoiding cloud endpoints. Both options work fully **offline or on a local network**.

---

## Push/Pull Data

```bash
# Upload (sync) tracked data to your configured remote (local or LAN)
uv run dvc push

# If cloning this repo elsewhere, pull data down from the remote:
uv run dvc pull
```

> **Git** moves **code + DVC metadata**; **DVC** moves **large data**.

---

## Build Reproducible Pipelines (`dvc stage add`, `dvc repro`)

Let’s say you have a script `scripts/prepare.py` that reads `data/raw.csv` and outputs `data/clean.csv`.

```bash
# Create folders for scripts & outputs
mkdir -p scripts
# (Add your Python script at scripts/prepare.py)

# Add a pipeline stage that runs inside uv's environment
uv run dvc stage add -n prepare \
  -d data/raw.csv -d scripts/prepare.py \
  -o data/clean.csv \
  uv run python scripts/prepare.py --in data/raw.csv --out data/clean.csv

# DVC writes dvc.yaml and dvc.lock
git add dvc.yaml dvc.lock
git commit -m "Add 'prepare' stage"
```

Run (reproduce) the pipeline:

```bash
uv run dvc repro
```

View the pipeline graph:

```bash
uv run dvc dag
```

---

## Metrics & Params (Optional but Useful)

Track metrics (e.g., JSON) and parameters (YAML):

```bash
# Example: metrics.json produced by a stage
uv run dvc metrics show       # quick table of metrics across commits
uv run dvc metrics diff       # compare metrics between Git commits/tags

# Parameters (params.yaml) consumed by your scripts
# Use in a stage via: --param-file params.yaml
uv run dvc params diff        # compare params across commits
```

> This helps you **track model scores** and **hyperparameters** over time, locally.

---

## Experiments (Optional)

Quickly branch and compare experiments without polluting Git history:

```bash
# Run an experiment with a param change (e.g., learning rate)
uv run dvc exp run -S train.lr=0.01

# List and compare experiments
uv run dvc exp show

# Promote a good experiment to your main workspace
uv run dvc exp apply <exp-id>
git commit -am "Adopt experiment results"
```

---

## Garbage Collection & Cleaning Up

```bash
# Remove unused cache objects (be cautious; keep what you need on current branch/tags)
uv run dvc gc

# Clean untracked files (like regular Git clean)
git clean -fd
```

---

## Daily Workflow Cheat Sheet

```bash
# Track new/updated data
uv run dvc add data/new_file.parquet
git add data/new_file.parquet.dvc
git commit -m "Track new data"

# Update pipeline code & run
git add scripts/*.py
git commit -m "Update pipeline code"
uv run dvc repro

# Sync data to local/LAN remote
uv run dvc push

# On another machine (same LAN remote):
git clone <repo>
cd <repo>
uv venv && uv pip install "dvc[ssh]"
uv run dvc pull
uv run dvc repro   # fully reproducible
```

---

## Troubleshooting (Local/LAN setups)

* **Permissions on local remote**: ensure you can read/write the folder (e.g., `/srv/dvcstore`).
* **SSH remote errors**: verify key auth, user permissions, and that the path exists on the remote host.
* **Slow copies**: the `cache.type` setting (`hardlink,symlink`) reduces duplication on local filesystems.
* **Windows symlinks**: may require Developer Mode or admin rights; otherwise rely on `hardlink`.
* **Stay offline**: stick to `local` or `ssh` remotes; do not configure cloud providers.

---

### That’s it!

You now have a **local/LAN-only**, **fully reproducible** DVC workflow using the **`uv`** Python package manager.
