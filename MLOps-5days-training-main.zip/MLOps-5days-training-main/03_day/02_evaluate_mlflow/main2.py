import mlflow
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

mlflow.set_tracking_uri("http://localhost:8080")
mlflow.set_experiment("02-evaluate-mlflow")

mlflow.sklearn.autolog()



# Generate sample data
X, y = make_classification(n_samples=1000, n_features=20, n_classes=2, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)


# Create evaluation dataset
eval_data = pd.DataFrame(X_test)
eval_data["target"] = y_test


from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB


def ensemble_prediction_function(input_data):
    """Ensemble function combining multiple base models."""

    # Initialize base models
    models = {
        "rf": RandomForestClassifier(n_estimators=50, random_state=42),
        "lr": LogisticRegression(random_state=42),
        "svm": SVC(probability=True, random_state=42),
        "nb": GaussianNB(),
    }

    # Train base models (in practice, these would be pre-trained)
    predictions = {}
    probabilities = {}

    for name, model in models.items():
        # Note: This is for demonstration - in practice, models would be pre-trained
        model.fit(X_train, y_train)
        predictions[name] = model.predict(input_data)

        if hasattr(model, "predict_proba"):
            probabilities[name] = model.predict_proba(input_data)[:, 1]
        else:
            probabilities[name] = predictions[name].astype(float)

    # Ensemble strategies
    # 1. Majority voting
    pred_array = np.array(list(predictions.values()))
    majority_vote = np.apply_along_axis(
        lambda x: np.bincount(x).argmax(), axis=0, arr=pred_array
    )

    # 2. Weighted average of probabilities
    prob_array = np.array(list(probabilities.values()))
    weights = np.array([0.4, 0.3, 0.2, 0.1])  # RF, LR, SVM, NB
    weighted_probs = np.average(prob_array, axis=0, weights=weights)
    weighted_predictions = (weighted_probs > 0.5).astype(int)

    # 3. Dynamic ensemble based on confidence
    confidence_scores = np.std(prob_array, axis=0)
    high_confidence_mask = confidence_scores < 0.2

    final_predictions = majority_vote.copy()
    final_predictions[high_confidence_mask] = weighted_predictions[high_confidence_mask]

    return final_predictions


with mlflow.start_run(run_name="Ensemble_Function_Evaluation"):
    # Log ensemble configuration
    mlflow.log_params(
        {
            "base_models": "RF, LR, SVM, NB",
            "ensemble_strategy": "dynamic_confidence_based",
            "confidence_threshold": 0.2,
            "weights": [0.4, 0.3, 0.2, 0.1],
        }
    )

    result = mlflow.evaluate(
        ensemble_prediction_function,
        eval_data,
        targets="target",
        model_type="classifier",
    )

    print(f"Ensemble Function Accuracy: {result.metrics['accuracy_score']:.3f}")