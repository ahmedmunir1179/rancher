import mlflow
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

mlflow.set_tracking_uri("http://localhost:8080")
mlflow.set_experiment("02-evaluate-mlflow")

mlflow.sklearn.autolog()



# Generate sample data
X, y = make_classification(n_samples=1000, n_features=20, n_classes=2, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


def complete_pipeline_function(input_data):
    """Function that includes preprocessing, feature engineering, and prediction."""

    # Preprocessing
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(input_data)

    # Feature engineering
    pca = PCA(n_components=10)
    pca_features = pca.fit_transform(scaled_data)

    # Create additional features
    feature_interactions = pca_features[:, 0] * pca_features[:, 1]
    feature_ratios = pca_features[:, 0] / (pca_features[:, 1] + 1e-8)

    # Combine features
    enhanced_features = np.column_stack(
        [
            pca_features,
            feature_interactions.reshape(-1, 1),
            feature_ratios.reshape(-1, 1),
        ]
    )

    # Model prediction
    model = RandomForestClassifier(n_estimators=50, random_state=42)
    # Note: In practice, you'd fit this on training data separately
    model.fit(enhanced_features, np.random.choice([0, 1], size=len(enhanced_features)))

    predictions = model.predict(enhanced_features)
    return predictions


# Create evaluation dataset
eval_data = pd.DataFrame(X_test)
eval_data["target"] = y_test

with mlflow.start_run(run_name="Complete_Pipeline_Function"):
    # Log pipeline configuration
    mlflow.log_params(
        {
            "preprocessing": "StandardScaler + PCA",
            "pca_components": 10,
            "feature_engineering": "interactions + ratios",
            "model": "RandomForest",
        }
    )

    result = mlflow.evaluate(
        complete_pipeline_function, eval_data, targets="target", model_type="classifier"
    )

    print(f"Pipeline Function Performance: {result.metrics['accuracy_score']:.3f}")