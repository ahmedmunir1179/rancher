import mlflow
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

mlflow.set_tracking_uri("http://localhost:8080")
mlflow.set_experiment("02-evaluate-mlflow")

mlflow.sklearn.autolog()

# Generate sample data
X, y = make_classification(n_samples=1000, n_features=20, n_classes=2, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# Create evaluation dataset
eval_data = pd.DataFrame(X_test)
eval_data["target"] = y_test

def business_rule_function(input_data):
    """Function combining ML predictions with business rules."""

    # If input_data is a DataFrame, convert to numpy array for indexing
    if isinstance(input_data, pd.DataFrame):
        input_array = input_data.values
    else:
        input_array = input_data

    # Get base ML predictions
    ml_model = RandomForestClassifier(n_estimators=100, random_state=42)
    ml_model.fit(X_train, y_train)
    ml_predictions = ml_model.predict(input_array)
    ml_probabilities = ml_model.predict_proba(input_array)[:, 1]

    # Business rules (example domain: loan approval)
    # Rule 1: High-risk features override ML prediction
    high_risk_mask = input_array[:, 0] < -2  # Example: low credit score

    # Rule 2: Low confidence ML predictions get conservative treatment
    low_confidence_mask = np.abs(ml_probabilities - 0.5) < 0.1

    # Rule 3: Combination rules for edge cases
    edge_case_mask = (input_array[:, 1] > 2) & (input_array[:, 2] < -1)

    # Apply business logic
    final_predictions = ml_predictions.copy()

    # Override high-risk cases
    final_predictions[high_risk_mask] = 0  # Reject

    # Conservative approach for low confidence
    final_predictions[low_confidence_mask & (ml_probabilities < 0.6)] = 0

    # Special handling for edge cases
    final_predictions[edge_case_mask] = 1  # Approve with conditions

    return final_predictions

with mlflow.start_run(run_name="Business_Rule_Function"):
    # Log business rule configuration
    mlflow.log_params(
        {
            "base_model": "RandomForest",
            "business_rules": "high_risk_override, confidence_threshold, edge_cases",
            "confidence_threshold": 0.6,
            "high_risk_feature": "feature_0 < -2",
        }
    )

    result = mlflow.evaluate(
        business_rule_function, eval_data, targets="target", model_type="classifier"
    )

    # Calculate rule impact
    ml_only_predictions = (
        RandomForestClassifier(n_estimators=100, random_state=42)
        .fit(X_train, y_train)
        .predict(X_test)
    )
    rule_based_predictions = business_rule_function(X_test)

    rule_changes = np.sum(ml_only_predictions != rule_based_predictions)
    change_rate = rule_changes / len(ml_only_predictions)

    mlflow.log_metrics(
        {
            "rule_changes": rule_changes,
            "rule_change_rate": change_rate,
            "ml_only_accuracy": (ml_only_predictions == y_test).mean(),
        }
    )

    print(f"Business Rule Function Accuracy: {result.metrics['accuracy_score']:.3f}")
    print(f"Rule Changes: {rule_changes} ({change_rate:.1%})")