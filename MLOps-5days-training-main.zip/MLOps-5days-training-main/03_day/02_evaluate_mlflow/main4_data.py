import mlflow

mlflow.set_tracking_uri("http://localhost:8080")
mlflow.set_experiment("03-evaluate-data")

mlflow.sklearn.autolog()

import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

# Generate sample data and train a model
X, y = make_classification(n_samples=1000, n_features=20, n_classes=2, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Generate predictions (this could be from a batch job, stored results, etc.)
predictions = model.predict(X_test)
prediction_probabilities = model.predict_proba(X_test)[:, 1]

# Create evaluation dataset with predictions already computed
eval_dataset = pd.DataFrame(
    {
        "prediction": predictions,
        "prediction_proba": prediction_probabilities,
        "target": y_test,
    }
)

# Add original features for analysis (optional)
feature_names = [f"feature_{i}" for i in range(X_test.shape[1])]
for i, feature_name in enumerate(feature_names):
    eval_dataset[feature_name] = X_test[:, i]

import mlflow.data

# Create MLflow dataset with prediction column specified
dataset = mlflow.data.from_pandas(
    eval_dataset,
    predictions="prediction",  # Specify prediction column
    targets="target",  # Specify target column
)

with mlflow.start_run():
    # Log the dataset
    mlflow.log_input(dataset, context="evaluation")

    # Evaluate using the dataset (predictions=None since specified in dataset)
    result = mlflow.evaluate(
        data=dataset,
        predictions=None,  # Already specified in dataset creation
        targets=None,  # Already specified in dataset creation
        model_type="classifier",
    )

    print("Evaluation completed using MLflow PandasDataset")