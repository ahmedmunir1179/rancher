# GitHub Actions — CI/CD Fundamentals (Same Format)

This README walks you through **CI/CD on GitHub Actions**: workflow triggers, jobs, runners, caching, artifacts, matrices, protected environments, **Docker build/push**, **Docker Compose test**, and **Python builds (with `uv`)**. It’s copy-paste friendly.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Repo Setup & First Workflow](#repo-setup--first-workflow)
3. [Workflow Triggers](#workflow-triggers)
4. [Jobs, Runners & Permissions](#jobs-runners--permissions)
5. [Python CI with `uv` (tests, lint, cache)](#python-ci-with-uv-tests-lint-cache)
6. [Build & Push Docker Images (Docker Hub/GHCR)](#build--push-docker-images-docker-hubghcr)
7. [Docker Compose Integration Tests](#docker-compose-integration-tests)
8. [Artifacts, Caching & Matrix Builds](#artifacts-caching--matrix-builds)
9. [Environments, Secrets & Protection](#environments-secrets--protection)
10. [Reusable & Composite Actions](#reusable--composite-actions)
11. [Concurrency, Conditions & Paths Filters](#concurrency-conditions--paths-filters)
12. [Troubleshooting](#troubleshooting)
13. [Daily Workflow Cheat Sheet](#daily-workflow-cheat-sheet)

---

## Prerequisites

* GitHub repository with Actions enabled.
* (Optional) **Docker Hub** or **GitHub Container Registry (GHCR)** account for pushing images.
* Define needed **secrets** in your repo/org settings (e.g., `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`, etc.).

> Tip: If you also run builds on your **LAN**, add a **self-hosted runner** and label it (e.g., `self-hosted`, `linux`, `lan`).

---

## Repo Setup & First Workflow

Create a minimal CI on push/PR:

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

permissions:
  contents: read

jobs:
  echo:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: echo "CI is alive ✅"
```

Commit and push:

```bash
git add .github/workflows/ci.yml
git commit -m "Add basic CI"
git push
```

---

## Workflow Triggers

Common events:

```yaml
on:
  push:
    branches: [ "main", "release/*" ]
    paths: [ "**.py", "Dockerfile", "compose.yaml" ]
  pull_request:
    types: [opened, synchronize, reopened, ready_for_review]
  workflow_dispatch: {}       # manual button
  schedule:
    - cron: "0 2 * * *"      # nightly at 02:00 UTC
  release:
    types: [published]
```

---

## Jobs, Runners & Permissions

```yaml
jobs:
  build:
    runs-on: ubuntu-latest      # or: windows-latest / macos-latest / self-hosted
    # runs-on: [self-hosted, linux, x64, lan]  # if you use your own LAN runner
    permissions:
      contents: read
      packages: write           # needed if pushing to GHCR
```

> Use `permissions:` at **job** or **workflow** level (principle of least privilege).

---

## Python CI with `uv` (tests, lint, cache)

Cache `uv` + dependencies, run linters/tests:

```yaml
# .github/workflows/python-ci.yml
name: Python CI (uv)

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    env:
      UV_CACHE_DIR: .uv-cache
    steps:
      - uses: actions/checkout@v4

      - name: Install Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Cache uv
        uses: actions/cache@v4
        with:
          path: |
            .uv-cache
            .venv
          key: uv-${{ runner.os }}-${{ hashFiles('**/pyproject.toml', '**/uv.lock', '**/requirements*.txt') }}
          restore-keys: |
            uv-${{ runner.os }}-

      - name: Install uv
        run: |
          pip install uv

      - name: Create venv & install deps
        run: |
          uv venv
          uv pip install -r requirements.txt
          # or: uv pip install .[dev]   # if pyproject/optional extras

      - name: Lint
        run: |
          uv run pip install ruff
          uv run ruff check .

      - name: Test
        run: |
          uv run pip install pytest
          uv run pytest -q --maxfail=1 --disable-warnings
```

> If you use **`pyproject.toml`**: swap `requirements.txt` with `uv pip install -r pyproject.toml` or `uv pip install .`.

---

## Build & Push Docker Images (Docker Hub/GHCR)

**Docker Hub** example:

```yaml
# .github/workflows/docker-publish.yml
name: Docker Publish

on:
  push:
    branches: [ "main" ]
    tags: [ "v*" ]
  workflow_dispatch: {}

permissions:
  contents: read

jobs:
  docker:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up QEMU (for multi-arch)
        uses: docker/setup-qemu-action@v3

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Login to Docker Hub
        uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}

      - name: Build & Push
        uses: docker/build-push-action@v6
        with:
          context: .
          file: ./Dockerfile
          push: true
          platforms: linux/amd64,linux/arm64
          tags: |
            ${{ secrets.DOCKERHUB_USERNAME }}/myapp:latest
            ${{ secrets.DOCKERHUB_USERNAME }}/myapp:${{ github.sha }}
```

**GHCR** variant (skip login to Docker Hub, use GH token):

```yaml
      - name: Login to GHCR
        uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Build & Push to GHCR
        uses: docker/build-push-action@v6
        with:
          push: true
          tags: ghcr.io/${{ github.repository_owner }}/myapp:latest
```

---

## Docker Compose Integration Tests

Spin up services, run tests against them, tear down:

```yaml
# .github/workflows/compose-integration.yml
name: Compose Integration

on: [push, pull_request]

jobs:
  integration:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Build images (optional)
        run: docker compose build

      - name: Start stack
        run: docker compose up -d

      - name: Wait for API health
        run: |
          for i in {1..30}; do
            curl -fsS http://localhost:8000/health && break
            sleep 2
          done

      - name: Run integration tests
        run: |
          pip install uv
          uv venv
          uv pip install -r tests/requirements.txt
          uv run pytest tests/integration -q

      - name: Dump logs on failure
        if: failure()
        run: docker compose logs --no-color > compose-logs.txt

      - name: Upload logs artifact
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: compose-logs
          path: compose-logs.txt

      - name: Tear down
        if: always()
        run: docker compose down -v
```

---

## Artifacts, Caching & Matrix Builds

**Artifacts (test reports, builds):**

```yaml
- name: Upload Coverage
  uses: actions/upload-artifact@v4
  with:
    name: coverage
    path: coverage.xml
```

**Dependencies cache (generic example):**

```yaml
- uses: actions/cache@v4
  with:
    path: .cache
    key: cache-${{ runner.os }}-${{ hashFiles('**/lockfiles*') }}
```

**Matrix (OS / Python versions):**

```yaml
strategy:
  fail-fast: false
  matrix:
    os: [ubuntu-latest, windows-latest]
    python: ["3.10", "3.12"]

runs-on: ${{ matrix.os }}

steps:
  - uses: actions/setup-python@v5
    with:
      python-version: ${{ matrix.python }}
```

---

## Environments, Secrets & Protection

**Environments** let you gate deploys with reviewers and use environment-scoped secrets:

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  workflow_dispatch:

jobs:
  deploy:
    runs-on: ubuntu-latest
    environment:
      name: production
      url: https://myapp.example.com
    steps:
      - uses: actions/checkout@v4
      - run: |
          curl -H "Authorization: Bearer $SECRET_TOKEN" https://deploy.example.com
        env:
          SECRET_TOKEN: ${{ secrets.PROD_DEPLOY_TOKEN }}
```

> In repo Settings → Environments → **production**: add required reviewers & secrets.

---

## Reusable & Composite Actions

**Reusable workflow** you can call from many repos:

```yaml
# .github/workflows/reusable-test.yml
name: Reusable Test
on:
  workflow_call:
    inputs:
      python:
        required: true
        type: string

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ inputs.python }}
      - run: pip install -r requirements.txt && pytest -q
```

**Caller:**

```yaml
# .github/workflows/call-reusable.yml
name: Call Reusable
on: [push]
jobs:
  use-it:
    uses: ./.github/workflows/reusable-test.yml
    with:
      python: "3.12"
```

**Composite action** (package repeated steps):

```yaml
# .github/actions/setup-uv/action.yml
name: "Setup uv"
runs:
  using: "composite"
  steps:
    - run: pip install uv
      shell: bash
```

Use it:

```yaml
- uses: ./.github/actions/setup-uv
```

---

## Concurrency, Conditions & Paths Filters

**Avoid overlapping runs (cancel in-progress):**

```yaml
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
```

**Conditional steps:**

```yaml
- name: Only on tag
  if: startsWith(github.ref, 'refs/tags/')
  run: echo "Tagged release"
```

**Paths filters (speed up CI):**

```yaml
on:
  push:
    paths:
      - "**.py"
      - "Dockerfile"
      - "!docs/**"
```

---

## Troubleshooting

* **Permission denied pushing images** → ensure registry login and `packages: write` (GHCR).
* **Cache not restoring** → check `key`/`restore-keys` and cache `path`.
* **Secrets missing in PRs from forks** → GitHub masks secrets; use `pull_request_target` cautiously or require branches.
* **Flaky integration tests** → add retries, health checks, and dump logs as artifacts.
* **Self-hosted runner offline** → check service status, labels, network, and disk space.

---

## Daily Workflow Cheat Sheet

```yaml
# 1) Lint & test on push/PR
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - run: pip install -r requirements.txt
      - run: ruff check .
      - run: pytest -q

# 2) Build & push Docker image on main/tag
name: Docker Publish
on:
  push:
    branches: [main]
    tags: [v*]
jobs:
  docker:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/setup-buildx-action@v3
      - uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with:
          push: true
          tags: ${{ secrets.DOCKERHUB_USERNAME }}/myapp:latest

# 3) Compose integration tests
name: Compose Integration
on: [push]
jobs:
  it:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: docker compose up -d
      - run: pytest tests/integration -q
      - run: docker compose down -v
```

---

### You’re set!

You now have a practical, step-by-step **GitHub Actions CI/CD** guide with **Docker Hub**, **Compose**, **Dockerfile**, matrices, caching, artifacts, and protected deployments.
