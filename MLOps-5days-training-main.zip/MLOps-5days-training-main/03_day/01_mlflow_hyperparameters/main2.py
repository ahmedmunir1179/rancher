import mlflow
import mlflow.keras
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from mlflow.models import infer_signature
import numpy as np
import os

# Configure TensorFlow to avoid threading issues
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
tf.config.threading.set_inter_op_parallelism_threads(1)
tf.config.threading.set_intra_op_parallelism_threads(1)

# Set up MLflow experiment
mlflow.set_experiment("02-mnist-model-signature")

# Load and prepare data
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
x_train = x_train.reshape(60000, 784).astype("float32") / 255
x_test = x_test.reshape(10000, 784).astype("float32") / 255
y_train = keras.utils.to_categorical(y_train, 10)
y_test = keras.utils.to_categorical(y_test, 10)

# Define model architecture
def create_model():
    model = keras.Sequential(
        [
            layers.Dense(512, activation="relu", input_shape=(784,)),
            layers.Dropout(0.2),
            layers.Dense(256, activation="relu"),
            layers.Dropout(0.2),
            layers.Dense(10, activation="softmax"),
        ]
    )
    return model

# Training parameters
params = {
    "epochs": 10,
    "batch_size": 128,
    "learning_rate": 0.001,
    "optimizer": "adam",
    "loss_function": "categorical_crossentropy",
    "dropout_rate": 0.2,
    "hidden_units": [512, 256],
}

# Create and compile model
model = create_model()
model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=params["learning_rate"]),
    loss=params["loss_function"],
    metrics=["accuracy"]
)


with mlflow.start_run() as run:
    # Log training parameters
    mlflow.log_params(params)
    
    # Custom callback for enhanced logging
    class CustomMlflowCallback(keras.callbacks.Callback):
        def on_epoch_end(self, epoch, logs=None):
            if logs:
                # Log standard metrics
                mlflow.log_metrics({
                    "train_loss": logs.get("loss"),
                    "train_accuracy": logs.get("accuracy"),
                    "val_loss": logs.get("val_loss"),
                    "val_accuracy": logs.get("val_accuracy"),
                }, step=epoch)
                
                # Log learning rate every 5 epochs
                if epoch % 5 == 0:
                    lr = self.model.optimizer.learning_rate.numpy()
                    mlflow.log_metric("learning_rate", lr, step=epoch)
        
        def on_train_end(self, logs=None):
            # Log final model weights distribution
            weights = self.model.get_weights()
            avg_weight = np.mean([np.mean(w) for w in weights])
            mlflow.log_metric("avg_final_weight", avg_weight)

    # Create custom callback
    custom_callback = CustomMlflowCallback()

    # Train model
    print("Starting training with enhanced MLflow logging...")
    history = model.fit(
        x_train,
        y_train,
        batch_size=params["batch_size"],
        epochs=params["epochs"],
        validation_data=(x_test, y_test),
        callbacks=[custom_callback],
        verbose=1,
    )

    # Evaluate model
    test_loss, test_accuracy = model.evaluate(x_test, y_test, verbose=0)
    mlflow.log_metrics({"test_loss": test_loss, "test_accuracy": test_accuracy})

    # Prepare sample data for signature inference
    print("Inferring model signature...")
    sample_input = x_test[:100]
    sample_predictions = model.predict(sample_input, verbose=0)

    # Infer signature from sample data
    signature = infer_signature(sample_input, sample_predictions)

    # Log model with signature (without input example to avoid file path issues)
    print("Logging model with signature...")
    model_info = mlflow.keras.log_model(
        model, 
        "model", 
        signature=signature
    )

    print(f"Test accuracy: {test_accuracy:.4f}")
    print(f"Model logged with signature: {model_info.model_uri}")
    print("Training completed successfully!")