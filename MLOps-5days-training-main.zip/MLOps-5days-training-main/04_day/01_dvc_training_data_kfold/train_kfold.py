import argparse, json, os, subprocess, uuid
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import shap
from matplotlib import pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

def safe_run(cmd: str):
    print(f"\n$ {cmd}")
    # Fail loudly if DVC/Git not initialized; for demo we ignore return code here:
    subprocess.run(cmd, shell=True, check=False)

def shap_summary_plot(model, X_fold, out_png):
    # TreeExplainer is fast for tree models
    explainer = shap.TreeExplainer(model, feature_perturbation="interventional")
    # Use small background sample to keep this super fast for demo
    bg_idx = np.random.choice(len(X_fold), size=min(100, len(X_fold)), replace=False)
    shap_values = explainer.shap_values(X_fold[bg_idx])
    Path(out_png).parent.mkdir(parents=True, exist_ok=True)
    plt.figure()
    # For binary classifiers shap returns list [class0, class1]; use class1
    sv = shap_values[1] if isinstance(shap_values, list) else shap_values
    shap.summary_plot(sv, X_fold[bg_idx], show=False)
    plt.tight_layout()
    plt.savefig(out_png, dpi=160)
    plt.close()

def main(k: int, seed: int):
    # === Data (small, built-in) ===
    data = load_breast_cancer(as_frame=True)
    X = data.frame.drop(columns=["target"])
    y = data.frame["target"].values
    feature_names = X.columns.tolist()

    # Scale for good measure (RF doesn’t need it, but harmless)
    scaler = StandardScaler()
    X = pd.DataFrame(scaler.fit_transform(X), columns=feature_names)

    # === K-Fold ===
    skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
    run_id = str(uuid.uuid4())[:8]  # helpful if you want multiple runs

    all_metrics = []
    for fold, (tr_idx, te_idx) in enumerate(skf.split(X, y), start=1):
        print(f"\n=== Fold {fold}/{k} ===")
        Xtr, Xte = X.iloc[tr_idx].values, X.iloc[te_idx].values
        ytr, yte = y[tr_idx], y[te_idx]

        # Model
        model = RandomForestClassifier(
            n_estimators=200, max_depth=None, random_state=seed + fold, n_jobs=-1
        )
        model.fit(Xtr, ytr)
        p = model.predict(Xte)
        pprob = model.predict_proba(Xte)[:, 1]

        # Metrics
        metrics = {
            "fold": fold,
            "k": k,
            "accuracy": float(accuracy_score(yte, p)),
            "f1": float(f1_score(yte, p)),
            "roc_auc": float(roc_auc_score(yte, pprob)),
            "run_id": run_id,
        }

        # Save artifacts
        outdir = Path(f"artifacts/fold_{fold:02d}")
        outdir.mkdir(parents=True, exist_ok=True)
        joblib.dump(model, outdir / "model.joblib")
        with open(outdir / "metrics.json", "w") as f:
            json.dump(metrics, f, indent=2)
        # SHAP summary image
        shap_summary_plot(model, Xtr, outdir / "shap_summary.png")

        # Also save feature names so you can align SHAP later
        pd.Series(feature_names).to_csv(outdir / "features.csv", index=False)

        print("Saved:", list(map(str, outdir.iterdir())))
        all_metrics.append(metrics)

        # === DVC per-fold add + push (as requested) ===
        # Track the whole fold directory so model, metrics, plots are versioned together
        safe_run(f'dvc add {outdir}')
        # Commit the .dvc file so the metadata/history is in Git
        safe_run(f'git add {outdir}.dvc')
        safe_run(f'git commit -m "Add artifacts for fold {fold}"')
        # Push data to the configured DVC remote
        safe_run('dvc push')

    # Save aggregate metrics too (non-DVC; you can DVC-track it if you prefer)
    agg = pd.DataFrame(all_metrics)
    agg.to_csv("artifacts/metrics_overview.csv", index=False)
    print("\nAggregate metrics:\n", agg.describe())

    print("\nDone. Each fold’s artifacts are DVC-tracked and pushed.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    main(k=args.k, seed=args.seed)
