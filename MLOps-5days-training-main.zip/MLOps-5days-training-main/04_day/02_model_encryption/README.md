“uv-native” Python project that:

* uses **uv** for package/env management
* trains a light ML model (LogisticRegression on Iris)
* **encrypts** the trained model
* serves the **encrypted** model behind a **FastAPI** API (decrypted in-memory at startup)

---

# 1) Project layout

```
uv-ml-encrypted/
├─ pyproject.toml
├─ .env.sample
├─ README.md
├─ data/
│  └─ (optional)
├─ models/
│  ├─ encrypted_model.bin          # produced by training script
│  └─ model_meta.json              # small metadata sidecar
├─ scripts/
│  └─ train_encrypt.py             # trains + encrypts model
└─ app/
   ├─ __init__.py
   └─ main.py                      # FastAPI app (loads & decrypts)
```

---

# 2) Initialize with **uv** and add deps

```bash
# if you haven't installed uv:
# curl -LsSf https://astral.sh/uv/install.sh | sh

mkdir uv-ml-encrypted && cd uv-ml-encrypted
uv init --python 3.11

# add runtime deps
uv add fastapi uvicorn cryptography scikit-learn joblib pydantic-settings python-dotenv

# (optional) dev tooling
uv add --dev ruff pytest
```

---

# 3) `pyproject.toml` (PEP 621 + uv)

Paste this (replace the auto-generated `[project]` block from `uv init`):

```toml
[project]
name = "uv-ml-encrypted"
version = "0.1.0"
description = "Train, encrypt, and serve a light ML model using uv and FastAPI."
readme = "README.md"
requires-python = ">=3.11"
authors = [{ name = "You" }]

dependencies = [
  "fastapi>=0.115",
  "uvicorn>=0.30",
  "cryptography>=43.0",
  "scikit-learn>=1.4",
  "joblib>=1.4",
  "pydantic-settings>=2.3",
  "python-dotenv>=1.0",
]

[tool.uv]  # uv settings (optional)
dev-dependencies = ["ruff>=0.5", "pytest>=8.0"]

[tool.ruff.lint]
select = ["E","F","I","UP"]

[tool.ruff]
line-length = 100
```

---

# 4) Environment variables

Create `.env.sample`:

```env
# Copy this to .env and keep it SECRET in real deployments.
FERNET_KEY=
MODEL_PATH=models/encrypted_model.bin
MODEL_META=models/model_meta.json
```

> Tip: The training script below will **generate** a Fernet key if `FERNET_KEY` is empty and will print it once. In production, **pre-provision** the key via secret manager (AWS/GCP/Azure, Docker/K8s secrets, etc.) and do **not** commit `.env`.

---

# 5) Training + encryption script

Create `scripts/train_encrypt.py`:

```python
from __future__ import annotations

import base64
import io
import json
import os
from datetime import datetime

from cryptography.fernet import Fernet
from dotenv import load_dotenv
from joblib import dump
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

load_dotenv()

MODEL_PATH = os.getenv("MODEL_PATH", "models/encrypted_model.bin")
MODEL_META = os.getenv("MODEL_META", "models/model_meta.json")
FERNET_KEY = os.getenv("FERNET_KEY", "")

os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)

def get_or_create_key() -> bytes:
    global FERNET_KEY
    if not FERNET_KEY:
        key = Fernet.generate_key()
        # Show once so you can store it securely (don’t log in prod)
        print("\n=== GENERATED NEW FERNET KEY (store securely!) ===")
        print(key.decode(), "\n")
        return key
    # Allow raw or base64 string
    try:
        # If it’s a valid base64 Fernet key already, just use it
        base64.urlsafe_b64decode(FERNET_KEY)
        return FERNET_KEY.encode()
    except Exception:
        # If you provided raw bytes accidentally, base64-encode it
        return base64.urlsafe_b64encode(FERNET_KEY.encode())

def main():
    # 1) load data
    iris = load_iris()
    X, y = iris.data, iris.target

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    # 2) light model
    clf = LogisticRegression(max_iter=500, n_jobs=None)
    clf.fit(X_tr, y_tr)

    acc = accuracy_score(y_te, clf.predict(X_te))
    print(f"Test accuracy: {acc:.4f}")

    # 3) serialize to bytes (joblib -> BytesIO)
    buf = io.BytesIO()
    dump(clf, buf)  # joblib.dump
    model_bytes = buf.getvalue()

    # 4) encrypt
    key = get_or_create_key()
    f = Fernet(key)
    encrypted = f.encrypt(model_bytes)

    # 5) save artifacts
    with open(MODEL_PATH, "wb") as fbin:
        fbin.write(encrypted)

    meta = {
        "created_at": datetime.utcnow().isoformat() + "Z",
        "algo": "sklearn.linear_model.LogisticRegression",
        "dataset": "sklearn.datasets.load_iris",
        "test_accuracy": acc,
        "encryption": "Fernet (AES128 in CBC + HMAC, time-keyed tokens)",
        "model_path": MODEL_PATH,
    }
    with open(MODEL_META, "w") as fj:
        json.dump(meta, fj, indent=2)

    print(f"Encrypted model saved to: {MODEL_PATH}")
    print(f"Metadata saved to:       {MODEL_META}")

if __name__ == "__main__":
    main()
```

Run it:

```bash
# optional: copy sample env and fill FERNET_KEY yourself (or let script generate)
cp .env.sample .env
uv run python scripts/train_encrypt.py
```

---

# 6) FastAPI app to serve the **encrypted** model

Create `app/main.py`:

```python
from __future__ import annotations

import io
import os
from typing import List

from cryptography.fernet import Fernet
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from joblib import load as joblib_load
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

load_dotenv()

class Settings(BaseSettings):
    FERNET_KEY: str
    MODEL_PATH: str = "models/encrypted_model.bin"

settings = Settings()  # reads from env

def _load_model():
    # Decode/normalize key
    key_bytes = settings.FERNET_KEY.encode()
    try:
        # if already base64 Fernet key
        Fernet(key_bytes)
        f = Fernet(key_bytes)
    except Exception:
        # try to fix if raw -> base64
        import base64
        f = Fernet(base64.urlsafe_b64encode(key_bytes))

    # read encrypted bytes
    if not os.path.exists(settings.MODEL_PATH):
        raise FileNotFoundError(f"Encrypted model not found at {settings.MODEL_PATH}")
    with open(settings.MODEL_PATH, "rb") as fbin:
        encrypted = fbin.read()

    # decrypt to bytes -> load model from memory
    decrypted = f.decrypt(encrypted)
    model = joblib_load(io.BytesIO(decrypted))
    return model

app = FastAPI(title="Encrypted ML Model API")

# Decrypt once at startup into RAM (never write plaintext to disk)
MODEL = _load_model()

class PredictRequest(BaseModel):
    # 2D array: list of samples; each sample is 4 floats for Iris: [sepal_len, sepal_wid, petal_len, petal_wid]
    samples: List[List[float]] = Field(..., description="2D list: n_samples x n_features")

class PredictResponse(BaseModel):
    predictions: List[int]

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": MODEL is not None}

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    try:
        preds = MODEL.predict(req.samples)
        return PredictResponse(predictions=[int(x) for x in preds])
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
```

Run the API:

```bash
# ensure .env has FERNET_KEY and MODEL_PATH that match your artifacts
uv run uvicorn app.main:app --reload --port 8000
```

Test:

```bash
curl -X POST http://127.0.0.1:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"samples":[[5.1,3.5,1.4,0.2],[6.2,3.4,5.4,2.3]]}'
```

---

# 7) README (quickstart)

Create `README.md`:

````markdown
# uv-ml-encrypted

Train a light ML model, encrypt it, and serve behind a FastAPI API. Uses **uv** for package and env management.

## Prereqs
- Python 3.11+
- [uv](https://docs.astral.sh/uv/)

## Setup
```bash
uv sync
cp .env.sample .env
# (Optional) set FERNET_KEY in .env now; otherwise the script will generate one and print it once.
````

## Train + Encrypt

```bash
uv run python scripts/train_encrypt.py
```

Artifacts:

* `models/encrypted_model.bin`
* `models/model_meta.json`

If a new key was printed, **store it securely** (cloud secret manager, KMS, etc.). Update `.env` for serving.

## Serve API

```bash
uv run uvicorn app.main:app --reload --port 8000
```

### Endpoints

* `GET /health`
* `POST /predict`

```json
{
  "samples": [[5.1,3.5,1.4,0.2]]
}
```

## Notes

* The plaintext model never touches disk on the server; it’s **decrypted in-memory** only.
* Use container/K8s/Docker secrets for `FERNET_KEY` in production.
* Rotate keys by re-encrypting the model with a new key and restarting the service.

```

---

## Security & ops tips (concise)

- **Key management:** store `FERNET_KEY` in a secret manager (AWS Secrets Manager + IAM/KMS, GCP Secret Manager, Azure Key Vault). Never commit it.  
- **At-rest:** only the **encrypted** model is on disk; plaintext lives in memory. Consider running the API in an isolated container.  
- **Rotation:** keep a tiny script to decrypt with old key → re-encrypt with new key; deploy new key & artifact together.  
- **Hardening:** run `uvicorn` behind a reverse proxy, add auth (API key/JWT), enable TLS, and restrict `/predict` rate/size.

---


