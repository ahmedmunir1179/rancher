from __future__ import annotations

import base64
import io
import json
import os
from datetime import datetime, timezone

from cryptography.fernet import Fernet
from dotenv import load_dotenv
from joblib import dump
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

load_dotenv()

MODEL_PATH = os.getenv("MODEL_PATH", "models/encrypted_model.bin")
MODEL_META = os.getenv("MODEL_META", "models/model_meta.json")
FERNET_KEY = os.getenv("FERNET_KEY", "")

os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)

def get_or_create_key() -> bytes:
    global FERNET_KEY
    if not FERNET_KEY:
        key = Fernet.generate_key()
        # Show once so you can store it securely (don't log in prod)
        print("\n=== GENERATED NEW FERNET KEY (store securely!) ===")
        print(key.decode(), "\n")
        return key
    
    # If FERNET_KEY is provided, it should be a valid Fernet key (base64-encoded)
    try:
        # Validate that it's a proper Fernet key by trying to create a Fernet instance
        # This will raise ValueError if the key is invalid
        Fernet(FERNET_KEY.encode())
        return FERNET_KEY.encode()
    except ValueError as e:
        print(f"Invalid Fernet key provided: {e}")
        print("Generating a new key instead...")
        key = Fernet.generate_key()
        print("\n=== GENERATED NEW FERNET KEY (store securely!) ===")
        print(key.decode(), "\n")
        return key

def main():
    # 1) load data
    iris = load_iris()
    X, y = iris.data, iris.target

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    # 2) light model
    clf = LogisticRegression(max_iter=500, n_jobs=None)
    clf.fit(X_tr, y_tr)

    acc = accuracy_score(y_te, clf.predict(X_te))
    print(f"Test accuracy: {acc:.4f}")

    # 3) serialize to bytes (joblib -> BytesIO)
    buf = io.BytesIO()
    dump(clf, buf)  # joblib.dump
    model_bytes = buf.getvalue()

    # 4) encrypt
    key = get_or_create_key()
    f = Fernet(key)
    encrypted = f.encrypt(model_bytes)

    # 5) save artifacts
    with open(MODEL_PATH, "wb") as fbin:
        fbin.write(encrypted)

    meta = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "algo": "sklearn.linear_model.LogisticRegression",
        "dataset": "sklearn.datasets.load_iris",
        "test_accuracy": acc,
        "encryption": "Fernet (AES128 in CBC + HMAC, time-keyed tokens)",
        "model_path": MODEL_PATH,
    }
    with open(MODEL_META, "w") as fj:
        json.dump(meta, fj, indent=2)

    print(f"Encrypted model saved to: {MODEL_PATH}")
    print(f"Metadata saved to:       {MODEL_META}")

if __name__ == "__main__":
    main()
