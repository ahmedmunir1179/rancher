from __future__ import annotations

import io
import os
from typing import List

from cryptography.fernet import Fernet
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from joblib import load as joblib_load
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

load_dotenv()

class Settings(BaseSettings):
    FERNET_KEY: str
    MODEL_PATH: str = "models/encrypted_model.bin"

settings = Settings()  # reads from env

def _load_model():
    # Decode/normalize key
    key_bytes = settings.FERNET_KEY.encode()
    try:
        # if already base64 Fernet key
        Fernet(key_bytes)
        f = Fernet(key_bytes)
    except Exception:
        # try to fix if raw -> base64
        import base64
        f = Fernet(base64.urlsafe_b64encode(key_bytes))

    # read encrypted bytes
    if not os.path.exists(settings.MODEL_PATH):
        raise FileNotFoundError(f"Encrypted model not found at {settings.MODEL_PATH}")
    with open(settings.MODEL_PATH, "rb") as fbin:
        encrypted = fbin.read()

    # decrypt to bytes -> load model from memory
    decrypted = f.decrypt(encrypted)
    model = joblib_load(io.BytesIO(decrypted))
    return model

app = FastAPI(title="Encrypted ML Model API")

# Decrypt once at startup into RAM (never write plaintext to disk)
MODEL = _load_model()

class PredictRequest(BaseModel):
    # 2D array: list of samples; each sample is 4 floats for Iris: [sepal_len, sepal_wid, petal_len, petal_wid]
    samples: List[List[float]] = Field(..., description="2D list: n_samples x n_features")

class PredictResponse(BaseModel):
    predictions: List[int]

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": MODEL is not None}

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    try:
        preds = MODEL.predict(req.samples)
        return PredictResponse(predictions=[int(x) for x in preds])
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
