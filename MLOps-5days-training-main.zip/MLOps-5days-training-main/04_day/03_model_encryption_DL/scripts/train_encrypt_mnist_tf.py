from __future__ import annotations
import base64
import io
import json
import os
import tempfile
from datetime import datetime

import numpy as np
from cryptography.fernet import Fernet
from dotenv import load_dotenv
from tensorflow import keras

load_dotenv()

FERNET_KEY = os.getenv("FERNET_KEY", "")
TF_MODEL_ENC = os.getenv("TF_MODEL_ENC", "models/mnist_encrypted_model.h5.bin")
TF_MODEL_META = os.getenv("TF_MODEL_META", "models/mnist_model_meta.json")
TF_DATA_PATH = os.getenv("TF_DATA_PATH", "data/mnist.npz")

os.makedirs(os.path.dirname(TF_MODEL_ENC), exist_ok=True)
os.makedirs(os.path.dirname(TF_DATA_PATH), exist_ok=True)

def _get_key() -> bytes:
    if not FERNET_KEY:
        key = Fernet.generate_key()
        print("\n=== GENERATED NEW FERNET KEY (store securely!) ===")
        print(key.decode(), "\n")
        return key
    # normalize to Fernet b64 key
    try:
        base64.urlsafe_b64decode(FERNET_KEY)
        return FERNET_KEY.encode()
    except Exception:
        return base64.urlsafe_b64encode(FERNET_KEY.encode())

def _save_mnist_locally() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # Download (if missing) and cache a local copy
    (x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
    np.savez_compressed(TF_DATA_PATH, x_train=x_train, y_train=y_train, x_test=x_test, y_test=y_test)
    return x_train, y_train, x_test, y_test

def _load_mnist_from_disk() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not os.path.exists(TF_DATA_PATH):
        return _save_mnist_locally()
    with np.load(TF_DATA_PATH) as d:
        return d["x_train"], d["y_train"], d["x_test"], d["y_test"]

def build_model(input_shape=(28, 28, 1), num_classes=10) -> keras.Model:
    inputs = keras.Input(shape=input_shape)
    x = keras.layers.Reshape((28, 28, 1))(inputs) if len(input_shape) == 2 else inputs
    x = keras.layers.Conv2D(16, 3, activation="relu")(x)
    x = keras.layers.MaxPool2D()(x)
    x = keras.layers.Conv2D(32, 3, activation="relu")(x)
    x = keras.layers.GlobalAveragePooling2D()(x)
    x = keras.layers.Dense(32, activation="relu")(x)
    outputs = keras.layers.Dense(num_classes, activation="softmax")(x)
    model = keras.Model(inputs, outputs)
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return model

def main():
    # 1) Load/save MNIST
    x_train, y_train, x_test, y_test = _load_mnist_from_disk()

    # 2) Preprocess
    x_train = x_train.astype("float32") / 255.0
    x_test  = x_test.astype("float32") / 255.0
    # Keras will accept (N,28,28) for our Reshape layer; no need to expand dims here.

    # 3) Model
    model = build_model(input_shape=(28, 28), num_classes=10)

    # 4) Train (light)
    model.fit(x_train, y_train, epochs=3, batch_size=128, validation_split=0.1, verbose=1)

    # 5) Evaluate
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"MNIST test accuracy: {acc:.4f}")

    # 6) Serialize to bytes (Keras 3 recommends .keras or .h5)
    # Easiest: save to a temporary file, read bytes, then securely delete
    with tempfile.NamedTemporaryFile(suffix=".h5", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        model.save(tmp_path)  # writes HDF5 file
        with open(tmp_path, "rb") as f:
            model_bytes = f.read()
    finally:
        try:
            os.remove(tmp_path)
        except FileNotFoundError:
            pass

    # 7) Encrypt
    key = _get_key()
    f = Fernet(key)
    encrypted = f.encrypt(model_bytes)

    # 8) Save encrypted bytes + meta
    with open(TF_MODEL_ENC, "wb") as fb:
        fb.write(encrypted)

    meta = {
        "created_at": datetime.utcnow().isoformat() + "Z",
        "framework": "tensorflow-keras",
        "format": "HDF5",
        "dataset": "MNIST (keras.datasets.mnist)",
        "test_accuracy": float(acc),
        "encryption": "Fernet",
        "encrypted_path": TF_MODEL_ENC,
        "data_cache": TF_DATA_PATH,
    }
    with open(TF_MODEL_META, "w") as fj:
        json.dump(meta, fj, indent=2)

    print(f"Encrypted TF model: {TF_MODEL_ENC}")
    print(f"Metadata:           {TF_MODEL_META}")
    print(f"MNIST cached at:    {TF_DATA_PATH}")

if __name__ == "__main__":
    main()
