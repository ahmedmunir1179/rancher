from __future__ import annotations
import base64
import io
import os
import tempfile
from typing import List

from cryptography.fernet import Fernet
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings
from tensorflow import keras

load_dotenv()

class Settings(BaseSettings):
    FERNET_KEY: str
    TF_MODEL_ENC: str = "models/mnist_encrypted_model.h5.bin"

settings = Settings()

def _get_fernet(key_str: str) -> Fernet:
    try:
        return Fernet(key_str.encode())
    except Exception:
        return Fernet(base64.urlsafe_b64encode(key_str.encode()))

def _load_tf_model() -> keras.Model:
    if not os.path.exists(settings.TF_MODEL_ENC):
        raise FileNotFoundError(f"Encrypted TF model not found at {settings.TF_MODEL_ENC}")
    with open(settings.TF_MODEL_ENC, "rb") as f:
        enc = f.read()
    fernet = _get_fernet(settings.FERNET_KEY)
    plaintext = fernet.decrypt(enc)  # bytes of an .h5 file

    # Keras can't (reliably) load directly from BytesIO across all versions.
    # We write to a secure temp file, load, then immediately unlink.
    with tempfile.NamedTemporaryFile(suffix=".h5", delete=False) as tmp:
        tmp_path = tmp.name
        tmp.write(plaintext)
        tmp.flush()

    try:
        model = keras.models.load_model(tmp_path)
    finally:
        try:
            os.remove(tmp_path)
        except FileNotFoundError:
            pass
    return model

app = FastAPI(title="Encrypted MNIST TF Model API")

TF_MODEL = _load_tf_model()

class MnistPredictRequest(BaseModel):
    # each sample is either flattened 784-length or 28x28 nested list
    samples: List[List[float]] = Field(..., description="List of 28x28 or 1x784 pixel arrays (0..1)")

class MnistPredictResponse(BaseModel):
    predictions: List[int]
    conf: List[float]  # max softmax score per sample

def _reshape_samples(samples: List[List[float]]):
    import numpy as np
    X = np.array(samples, dtype="float32")
    # accept [N,784] or [N,28*28], or [N,28,28]
    if X.ndim == 2 and X.shape[1] == 784:
        X = X.reshape((-1, 28, 28))
    elif X.ndim == 2 and X.shape[1] != 784:
        raise ValueError("Each flattened sample must have length 784.")
    elif X.ndim == 3 and X.shape[1:] == (28, 28):
        pass
    else:
        raise ValueError("Samples must be [N,784] or [N,28,28].")
    return X

@app.get("/health-tf")
def health_tf():
    return {"status": "ok", "model_loaded": TF_MODEL is not None}

@app.post("/predict-tf", response_model=MnistPredictResponse)
def predict_tf(req: MnistPredictRequest):
    import numpy as np
    try:
        X = _reshape_samples(req.samples)
        # Ensure 0..1
        if X.max() > 1.0:
            X = X / 255.0
        probs = TF_MODEL.predict(X, verbose=0)
        preds = np.argmax(probs, axis=1)
        conf = probs.max(axis=1)
        return MnistPredictResponse(predictions=[int(p) for p in preds],
                                    conf=[float(c) for c in conf])
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
