got it—here’s an **MNIST-on-TensorFlow** add-on that matches your earlier criteria (uv-managed, train a light model, **encrypt** it, and **serve** via FastAPI).

I’m only adding new/changed bits so you can drop them straight into the project you just made.

---

# 0) Add TensorFlow (uv)

```bash
# from the project root
uv add "tensorflow>=2.15" h5py
```

> If you’re deploying on a slim CPU server, prefer `tensorflow-cpu` if your platform provides it.

---

# 1) New env vars

Append to your `.env.sample` (and `.env`):

```env
# TensorFlow MNIST artifacts
TF_MODEL_ENC=models/mnist_encrypted_model.h5.bin
TF_MODEL_META=models/mnist_model_meta.json
TF_DATA_PATH=data/mnist.npz
```

---

# 2) Save MNIST locally + train & encrypt (TensorFlow)

Create `scripts/train_encrypt_mnist_tf.py`:

```python
from __future__ import annotations
import base64
import io
import json
import os
import tempfile
from datetime import datetime

import numpy as np
from cryptography.fernet import Fernet
from dotenv import load_dotenv
from tensorflow import keras

load_dotenv()

FERNET_KEY = os.getenv("FERNET_KEY", "")
TF_MODEL_ENC = os.getenv("TF_MODEL_ENC", "models/mnist_encrypted_model.h5.bin")
TF_MODEL_META = os.getenv("TF_MODEL_META", "models/mnist_model_meta.json")
TF_DATA_PATH = os.getenv("TF_DATA_PATH", "data/mnist.npz")

os.makedirs(os.path.dirname(TF_MODEL_ENC), exist_ok=True)
os.makedirs(os.path.dirname(TF_DATA_PATH), exist_ok=True)

def _get_key() -> bytes:
    if not FERNET_KEY:
        key = Fernet.generate_key()
        print("\n=== GENERATED NEW FERNET KEY (store securely!) ===")
        print(key.decode(), "\n")
        return key
    # normalize to Fernet b64 key
    try:
        base64.urlsafe_b64decode(FERNET_KEY)
        return FERNET_KEY.encode()
    except Exception:
        return base64.urlsafe_b64encode(FERNET_KEY.encode())

def _save_mnist_locally() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # Download (if missing) and cache a local copy
    (x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
    np.savez_compressed(TF_DATA_PATH, x_train=x_train, y_train=y_train, x_test=x_test, y_test=y_test)
    return x_train, y_train, x_test, y_test

def _load_mnist_from_disk() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not os.path.exists(TF_DATA_PATH):
        return _save_mnist_locally()
    with np.load(TF_DATA_PATH) as d:
        return d["x_train"], d["y_train"], d["x_test"], d["y_test"]

def build_model(input_shape=(28, 28, 1), num_classes=10) -> keras.Model:
    inputs = keras.Input(shape=input_shape)
    x = keras.layers.Reshape((28, 28, 1))(inputs) if len(input_shape) == 2 else inputs
    x = keras.layers.Conv2D(16, 3, activation="relu")(x)
    x = keras.layers.MaxPool2D()(x)
    x = keras.layers.Conv2D(32, 3, activation="relu")(x)
    x = keras.layers.GlobalAveragePooling2D()(x)
    x = keras.layers.Dense(32, activation="relu")(x)
    outputs = keras.layers.Dense(num_classes, activation="softmax")(x)
    model = keras.Model(inputs, outputs)
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return model

def main():
    # 1) Load/save MNIST
    x_train, y_train, x_test, y_test = _load_mnist_from_disk()

    # 2) Preprocess
    x_train = x_train.astype("float32") / 255.0
    x_test  = x_test.astype("float32") / 255.0
    # Keras will accept (N,28,28) for our Reshape layer; no need to expand dims here.

    # 3) Model
    model = build_model(input_shape=(28, 28), num_classes=10)

    # 4) Train (light)
    model.fit(x_train, y_train, epochs=3, batch_size=128, validation_split=0.1, verbose=1)

    # 5) Evaluate
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"MNIST test accuracy: {acc:.4f}")

    # 6) Serialize to bytes (Keras 3 recommends .keras or .h5)
    # Easiest: save to a temporary file, read bytes, then securely delete
    with tempfile.NamedTemporaryFile(suffix=".h5", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        model.save(tmp_path)  # writes HDF5 file
        with open(tmp_path, "rb") as f:
            model_bytes = f.read()
    finally:
        try:
            os.remove(tmp_path)
        except FileNotFoundError:
            pass

    # 7) Encrypt
    key = _get_key()
    f = Fernet(key)
    encrypted = f.encrypt(model_bytes)

    # 8) Save encrypted bytes + meta
    with open(TF_MODEL_ENC, "wb") as fb:
        fb.write(encrypted)

    meta = {
        "created_at": datetime.utcnow().isoformat() + "Z",
        "framework": "tensorflow-keras",
        "format": "HDF5",
        "dataset": "MNIST (keras.datasets.mnist)",
        "test_accuracy": float(acc),
        "encryption": "Fernet",
        "encrypted_path": TF_MODEL_ENC,
        "data_cache": TF_DATA_PATH,
    }
    with open(TF_MODEL_META, "w") as fj:
        json.dump(meta, fj, indent=2)

    print(f"Encrypted TF model: {TF_MODEL_ENC}")
    print(f"Metadata:           {TF_MODEL_META}")
    print(f"MNIST cached at:    {TF_DATA_PATH}")

if __name__ == "__main__":
    main()
```

Run it:

```bash
uv run python scripts/train_encrypt_mnist_tf.py
```

Artifacts:

* `data/mnist.npz` (local cached dataset)
* `models/mnist_encrypted_model.h5.bin`
* `models/mnist_model_meta.json`

---

# 3) Serve the **encrypted TensorFlow model** (FastAPI)

Create `app/main_tf.py`:

```python
from __future__ import annotations
import base64
import io
import os
import tempfile
from typing import List

from cryptography.fernet import Fernet
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings
from tensorflow import keras

load_dotenv()

class Settings(BaseSettings):
    FERNET_KEY: str
    TF_MODEL_ENC: str = "models/mnist_encrypted_model.h5.bin"

settings = Settings()

def _get_fernet(key_str: str) -> Fernet:
    try:
        return Fernet(key_str.encode())
    except Exception:
        return Fernet(base64.urlsafe_b64encode(key_str.encode()))

def _load_tf_model() -> keras.Model:
    if not os.path.exists(settings.TF_MODEL_ENC):
        raise FileNotFoundError(f"Encrypted TF model not found at {settings.TF_MODEL_ENC}")
    with open(settings.TF_MODEL_ENC, "rb") as f:
        enc = f.read()
    fernet = _get_fernet(settings.FERNET_KEY)
    plaintext = fernet.decrypt(enc)  # bytes of an .h5 file

    # Keras can't (reliably) load directly from BytesIO across all versions.
    # We write to a secure temp file, load, then immediately unlink.
    with tempfile.NamedTemporaryFile(suffix=".h5", delete=False) as tmp:
        tmp_path = tmp.name
        tmp.write(plaintext)
        tmp.flush()

    try:
        model = keras.models.load_model(tmp_path)
    finally:
        try:
            os.remove(tmp_path)
        except FileNotFoundError:
            pass
    return model

app = FastAPI(title="Encrypted MNIST TF Model API")

TF_MODEL = _load_tf_model()

class MnistPredictRequest(BaseModel):
    # each sample is either flattened 784-length or 28x28 nested list
    samples: List[List[float]] = Field(..., description="List of 28x28 or 1x784 pixel arrays (0..1)")

class MnistPredictResponse(BaseModel):
    predictions: List[int]
    conf: List[float]  # max softmax score per sample

def _reshape_samples(samples: List[List[float]]):
    import numpy as np
    X = np.array(samples, dtype="float32")
    # accept [N,784] or [N,28*28], or [N,28,28]
    if X.ndim == 2 and X.shape[1] == 784:
        X = X.reshape((-1, 28, 28))
    elif X.ndim == 2 and X.shape[1] != 784:
        raise ValueError("Each flattened sample must have length 784.")
    elif X.ndim == 3 and X.shape[1:] == (28, 28):
        pass
    else:
        raise ValueError("Samples must be [N,784] or [N,28,28].")
    return X

@app.get("/health-tf")
def health_tf():
    return {"status": "ok", "model_loaded": TF_MODEL is not None}

@app.post("/predict-tf", response_model=MnistPredictResponse)
def predict_tf(req: MnistPredictRequest):
    import numpy as np
    try:
        X = _reshape_samples(req.samples)
        # Ensure 0..1
        if X.max() > 1.0:
            X = X / 255.0
        probs = TF_MODEL.predict(X, verbose=0)
        preds = np.argmax(probs, axis=1)
        conf = probs.max(axis=1)
        return MnistPredictResponse(predictions=[int(p) for p in preds],
                                    conf=[float(c) for c in conf])
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
```

Run the TF API:

```bash
# Make sure .env has FERNET_KEY and TF_MODEL_ENC set
uv run uvicorn app.main_tf:app --reload --port 8001
```

Quick test:

```bash
# one black image (all zeros) just to test the pipeline
curl -X POST http://127.0.0.1:8001/predict-tf \
  -H "Content-Type: application/json" \
  -d '{"samples":[['"$(python - <<'PY'
print(",".join(["0"]*784))
PY
)"']]}'
```

(Or send your own 28×28 normalized arrays; any shape `[N,784]` or `[N,28,28]` is accepted.)

---

## Notes & Options

* **Dataset saved locally:** `data/mnist.npz` is created once and reused.
* **Security:** FastAPI **decryption** happens at startup. For Keras, we use a **temp file** during load only, then immediately delete it. If you must avoid any disk writes, consider running the service on a RAM-backed filesystem for temp dirs or explore a pure in-memory HDF5 loader compatible with your Keras version.
* **Auth & TLS:** Put the API behind a gateway/reverse proxy with TLS and add auth (API keys/JWT) before exposing publicly.
