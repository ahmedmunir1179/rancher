**Ray** is an open-source Python framework designed for **scalable and distributed computing**, allowing you to easily parallelize and scale Python code from a laptop to a large cluster — *without changing much code*.

Here are the **core features of Ray** 👇

---

### 🧠 1. **Unified Distributed Computing Framework**

Ray provides a **single API** to handle many workloads — from **parallel loops** to **distributed ML training** and **model serving** — all within Python.

Example:

```python
import ray

ray.init()

@ray.remote
def f(x):
    return x * x

results = ray.get([f.remote(i) for i in range(4)])
print(results)
```

👉 Runs the function `f()` in parallel across cores or nodes.

---

### ⚙️ 2. **Task and Actor Abstractions**

* **Tasks** – stateless functions that run in parallel (`@ray.remote`).
* **Actors** – stateful, long-lived processes useful for building services or simulations.

Example:

```python
@ray.remote
class Counter:
    def __init__(self):
        self.value = 0
    def increment(self):
        self.value += 1
        return self.value

counter = Counter.remote()
print(ray.get(counter.increment.remote()))
```

---

### 🧩 3. **Built-in Libraries for Common Workloads**

Ray includes high-level libraries built on top of its core runtime:

* **Ray Tune** → hyperparameter tuning for ML models.
* **Ray Train** → distributed model training (integrates with PyTorch, TensorFlow, XGBoost).
* **Ray Data** → distributed data preprocessing pipelines.
* **Ray Serve** → scalable model serving and microservices.
* **RLlib** → reinforcement learning library.

---

### 🧮 4. **Scalable Cluster Management**

* Works **locally or on clusters** (Kubernetes, AWS, GCP, etc.).
* Automatically **schedules and balances workloads**.
* Dynamic **resource management** with CPU/GPU awareness.

```bash
ray start --head
ray start --address='auto'
```

---

### 🔍 5. **Fault Tolerance and Checkpointing**

* Automatic task retries if a node fails.
* Durable checkpointing with libraries like Ray Train and Tune.

---

### 📊 6. **Monitoring and Dashboard**

* Ray includes a **web-based dashboard** to visualize cluster resources, tasks, and logs.

  ```bash
  ray dashboard
  ```

  or automatically opens at `http://localhost:8265`.

---

### 🌐 7. **Integration with Ecosystem Tools**

* Works seamlessly with **NumPy, Pandas, PyTorch, TensorFlow, Dask**, and **scikit-learn**.
* Can connect to external orchestration systems like **Kubernetes**, **Airflow**, or **Prefect**.

---

### 🔐 8. **Autoscaling and Resource Awareness**

Ray automatically scales up/down based on demand and can schedule tasks on specific resources:

```python
@ray.remote(num_gpus=1)
def train_model():
    ...
```

---

### 🧭 9. **Composable Architecture**

You can mix multiple Ray libraries:

> e.g., preprocess with Ray Data → train with Ray Train → tune hyperparameters with Ray Tune → serve models with Ray Serve.

---

### 💡 10. **Ease of Use**

* Pythonic API.
* Minimal code changes to scale existing code.
* Excellent documentation and community support.

