# train_mnist_ray.py
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

import ray
from ray import tune
from ray.train import ScalingConfig
from ray.train import Checkpoint
from ray.train import report  # report metrics/checkpoints
from ray.train.torch import TorchTrainer, prepare_model

# ----- Model -----
class Net(nn.Module):
    def __init__(self, hidden=128, dropout=0.2):
        super().__init__()
        self.fc1 = nn.Linear(28 * 28, hidden)
        self.fc2 = nn.Linear(hidden, 10)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x.view(-1, 28 * 28)
        x = self.dropout(F.relu(self.fc1(x)))
        return self.fc2(x)

# ----- Data loaders (download once per worker) -----
def get_loaders(batch_size: int):
    tfm = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])
    train_set = datasets.MNIST(root="data", train=True, download=True, transform=tfm)
    test_set  = datasets.MNIST(root="data", train=False, download=True, transform=tfm)
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True, num_workers=2, pin_memory=True)
    test_loader  = DataLoader(test_set,  batch_size=512, shuffle=False, num_workers=2, pin_memory=True)
    return train_loader, test_loader

# ----- Train loop used by Ray Train -----
def train_loop(config):
    # config comes from Tune
    lr         = config.get("lr", 1e-3)
    batch_size = config.get("batch_size", 128)
    hidden     = config.get("hidden", 128)
    dropout    = config.get("dropout", 0.2)
    epochs     = config.get("epochs", 3)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = Net(hidden=hidden, dropout=dropout)
    model = prepare_model(model)  # wraps DDP if multi-worker GPU

    opt = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    train_loader, test_loader = get_loaders(batch_size)

    best_acc = 0.0
    for epoch in range(1, epochs + 1):
        # Train
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
            opt.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            opt.step()

        # Evaluate
        model.eval()
        correct = 0
        total = 0
        last_loss = 0.0
        with torch.no_grad():
            for xb, yb in test_loader:
                xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
                logits = model(xb)
                last_loss = criterion(logits, yb).item()
                preds = logits.argmax(1)
                correct += (preds == yb).sum().item()
                total += yb.size(0)
        acc = correct / total
        best_acc = max(best_acc, acc)

        # Save a lightweight checkpoint (best-so-far)
        ckpt = None
        if acc >= best_acc:
            state = {
                "model_state_dict": model.module.state_dict() if hasattr(model, "module") else model.state_dict(),
                "config": config,
                "accuracy": acc,
                "epoch": epoch,
            }
            ckpt_dir = "checkpoint"
            os.makedirs(ckpt_dir, exist_ok=True)
            path = os.path.join(ckpt_dir, "model.pt")
            torch.save(state, path)
            ckpt = Checkpoint.from_directory(ckpt_dir)

        # Report metrics (and optionally a checkpoint) to Tune
        if ckpt:
            report({"epoch": epoch, "accuracy": acc, "loss": last_loss}, checkpoint=ckpt)
        else:
            report({"epoch": epoch, "accuracy": acc, "loss": last_loss})

def main():
    ray.init(ignore_reinit_error=True)

    # Create a TorchTrainer (this defines *one* training run)
    base_trainer = TorchTrainer(
        train_loop_per_worker=train_loop,
        train_loop_config={  # default config; Tune will override values you search over
            "lr": 1e-3,
            "batch_size": 128,
            "hidden": 128,
            "dropout": 0.2,
            "epochs": 3,
        },
        scaling_config=ScalingConfig(
            num_workers=1,        # change to >1 to scale out
            use_gpu=torch.cuda.is_available()
        ),
    )

    # Hyperparameter search space
    param_space = {
        "train_loop_config": {
            "lr": tune.loguniform(1e-4, 3e-2),
            "batch_size": tune.choice([64, 128, 256]),
            "hidden": tune.choice([64, 128, 256, 384]),
            "dropout": tune.uniform(0.0, 0.5),
            "epochs": 5,  # keep small for demo
        }
    }

    tuner = tune.Tuner(
        base_trainer,
        param_space=param_space,
        tune_config=tune.TuneConfig(
            metric="accuracy",
            mode="max",
            num_samples=8,        # increase for better search
        ),
        run_config=tune.RunConfig(
            name="mnist_torch_tune",
            storage_path="~/ray_results"
        ),
    )

    results = tuner.fit()
    best = results.get_best_result(metric="accuracy", mode="max")
    print("Best accuracy:", best.metrics.get("accuracy"))
    print("Best config:", best.config)

    # ----- Load best checkpoint for inference -----
    ckpt = best.checkpoint
    with ckpt.as_directory() as ckpt_dir:
        state = torch.load(os.path.join(ckpt_dir, "model.pt"), map_location="cpu")
    model = Net(hidden=best.config["train_loop_config"]["hidden"], dropout=best.config["train_loop_config"]["dropout"])
    model.load_state_dict(state["model_state_dict"])
    model.eval()

    # Quick sanity prediction on a single sample
    tfm = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
    sample = datasets.MNIST(root="data", train=False, download=True, transform=tfm)[0]
    x, y = sample
    with torch.no_grad():
        pred = model(x.unsqueeze(0)).argmax(1).item()
    print(f"Sample true={y}, pred={pred}")

if __name__ == "__main__":
    main()
