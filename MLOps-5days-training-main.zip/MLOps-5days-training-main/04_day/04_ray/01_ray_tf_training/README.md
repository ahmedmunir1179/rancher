Awesome — here’s a compact, end-to-end example that **trains MNIST with Ray Train** and **does hyperparameter search with Ray Tune** (PyTorch). It runs on a laptop CPU/GPU or scales to a Ray cluster with almost no changes.

---

# 1) Install

```bash
pip install "ray[default]" torch torchvision
```

---

# 2) `train_mnist_ray.py`

```python
# train_mnist_ray.py
# train_mnist_ray.py
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

import ray
from ray import tune
from ray.train import ScalingConfig
from ray.train import Checkpoint
from ray.train import report  # report metrics/checkpoints
from ray.train.torch import TorchTrainer, prepare_model

# ----- Model -----
class Net(nn.Module):
    def __init__(self, hidden=128, dropout=0.2):
        super().__init__()
        self.fc1 = nn.Linear(28 * 28, hidden)
        self.fc2 = nn.Linear(hidden, 10)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x.view(-1, 28 * 28)
        x = self.dropout(F.relu(self.fc1(x)))
        return self.fc2(x)

# ----- Data loaders (download once per worker) -----
def get_loaders(batch_size: int):
    tfm = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])
    train_set = datasets.MNIST(root="data", train=True, download=True, transform=tfm)
    test_set  = datasets.MNIST(root="data", train=False, download=True, transform=tfm)
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True, num_workers=2, pin_memory=True)
    test_loader  = DataLoader(test_set,  batch_size=512, shuffle=False, num_workers=2, pin_memory=True)
    return train_loader, test_loader

# ----- Train loop used by Ray Train -----
def train_loop(config):
    # config comes from Tune
    lr         = config.get("lr", 1e-3)
    batch_size = config.get("batch_size", 128)
    hidden     = config.get("hidden", 128)
    dropout    = config.get("dropout", 0.2)
    epochs     = config.get("epochs", 3)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = Net(hidden=hidden, dropout=dropout)
    model = prepare_model(model)  # wraps DDP if multi-worker GPU

    opt = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    train_loader, test_loader = get_loaders(batch_size)

    best_acc = 0.0
    for epoch in range(1, epochs + 1):
        # Train
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
            opt.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            opt.step()

        # Evaluate
        model.eval()
        correct = 0
        total = 0
        last_loss = 0.0
        with torch.no_grad():
            for xb, yb in test_loader:
                xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
                logits = model(xb)
                last_loss = criterion(logits, yb).item()
                preds = logits.argmax(1)
                correct += (preds == yb).sum().item()
                total += yb.size(0)
        acc = correct / total
        best_acc = max(best_acc, acc)

        # Save a lightweight checkpoint (best-so-far)
        ckpt = None
        if acc >= best_acc:
            state = {
                "model_state_dict": model.module.state_dict() if hasattr(model, "module") else model.state_dict(),
                "config": config,
                "accuracy": acc,
                "epoch": epoch,
            }
            ckpt_dir = "checkpoint"
            os.makedirs(ckpt_dir, exist_ok=True)
            path = os.path.join(ckpt_dir, "model.pt")
            torch.save(state, path)
            ckpt = Checkpoint.from_directory(ckpt_dir)

        # Report metrics (and optionally a checkpoint) to Tune
        if ckpt:
            report({"epoch": epoch, "accuracy": acc, "loss": last_loss}, checkpoint=ckpt)
        else:
            report({"epoch": epoch, "accuracy": acc, "loss": last_loss})

def main():
    ray.init(ignore_reinit_error=True)

    # Create a TorchTrainer (this defines *one* training run)
    base_trainer = TorchTrainer(
        train_loop_per_worker=train_loop,
        train_loop_config={  # default config; Tune will override values you search over
            "lr": 1e-3,
            "batch_size": 128,
            "hidden": 128,
            "dropout": 0.2,
            "epochs": 3,
        },
        scaling_config=ScalingConfig(
            num_workers=1,        # change to >1 to scale out
            use_gpu=torch.cuda.is_available()
        ),
    )

    # Hyperparameter search space
    param_space = {
        "train_loop_config": {
            "lr": tune.loguniform(1e-4, 3e-2),
            "batch_size": tune.choice([64, 128, 256]),
            "hidden": tune.choice([64, 128, 256, 384]),
            "dropout": tune.uniform(0.0, 0.5),
            "epochs": 5,  # keep small for demo
        }
    }

    tuner = tune.Tuner(
        base_trainer,
        param_space=param_space,
        tune_config=tune.TuneConfig(
            metric="accuracy",
            mode="max",
            num_samples=8,        # increase for better search
        ),
        run_config=tune.RunConfig(
            name="mnist_torch_tune",
            storage_path="~/ray_results"
        ),
    )

    results = tuner.fit()
    best = results.get_best_result(metric="accuracy", mode="max")
    print("Best accuracy:", best.metrics.get("accuracy"))
    print("Best config:", best.config)

    # ----- Load best checkpoint for inference -----
    ckpt = best.checkpoint
    with ckpt.as_directory() as ckpt_dir:
        state = torch.load(os.path.join(ckpt_dir, "model.pt"), map_location="cpu")
    model = Net(hidden=best.config["train_loop_config"]["hidden"], dropout=best.config["train_loop_config"]["dropout"])
    model.load_state_dict(state["model_state_dict"])
    model.eval()

    # Quick sanity prediction on a single sample
    tfm = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
    sample = datasets.MNIST(root="data", train=False, download=True, transform=tfm)[0]
    x, y = sample
    with torch.no_grad():
        pred = model(x.unsqueeze(0)).argmax(1).item()
    print(f"Sample true={y}, pred={pred}")

if __name__ == "__main__":
    main()

```

---

# 3) Run it

```bash
python train_mnist_ray.py
```

## console output

```bash
Trial status: 8 TERMINATED
Current time: 2025-10-09 03:09:48. Total running time: 2min 22s
Logical resource usage: 2.0/10 CPUs, 0/0 GPUs
Current best trial: 2c61b_00003 with accuracy=0.9779 and params={'train_loop_config': {'lr': 0.0003296816682097134, 'batch_size': 64, 'hidden': 384, 'dropout': 0.3726631115432016, 'epochs': 5}}
╭───────────────────────────────────────────────────────────────────────────────────────────────────�2025-10-09 03:09:48,865    INFO tune.py:1009 -- Wrote the latest version of all result files and experiment state to '/Users/m.qasim/ray_results/mnist_torch_tune' in 0.0069s.
��─────────────────────────────────────────────────────────────────────────────────────────────────────╮
│ Trial name                 status         train_loop_config/lr     ...config/batch_size     ...oop_config/hidden     ...op_config/dropout     iter     total time (s)     epoch     accuracy       loss │
├─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│ TorchTrainer_2c61b_00000   TERMINATED              0.019045                         128                       64                0.0849278        5            76.0081         5       0.9366   0.454858 │
│ TorchTrainer_2c61b_00001   TERMINATED              0.000301151                      256                      384                0.382334         5            75.9852         5       0.9695   0.219887 │
│ TorchTrainer_2c61b_00002   TERMINATED              0.00219502                        64                      384                0.396209         5            77.377          5       0.9753   0.204612 │
│ TorchTrainer_2c61b_00003   TERMINATED              0.000329682                       64                      384                0.372663         5            78.7968         5       0.9779   0.162545 │
│ TorchTrainer_2c61b_00004   TERMINATED              0.000297281                      256                      384                0.0456223        5            75.8311         5       0.9695   0.17798  │
│ TorchTrainer_2c61b_00005   TERMINATED              0.000349185                      128                       64                0.42043          5            50.9453         5       0.9506   0.316862 │
│ TorchTrainer_2c61b_00006   TERMINATED              0.00860155                        64                      384                0.0719553        5            58.4978         5       0.9593   0.379231 │
│ TorchTrainer_2c61b_00007   TERMINATED              0.00498715                       256                      384                0.0945794        5            56.498          5       0.9733   0.181052 │
╰───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────100.0%────────────────────╯
100.0%
100.0%
100.0%


Best accuracy: 0.9779
Best config: {'train_loop_config': {'lr': 0.0003296816682097134, 'batch_size': 64, 'hidden': 384, 'dropout': 0.3726631115432016, 'epochs': 5}}
Sample true=7, pred=7
```

**Scale up**: change `num_workers` in `ScalingConfig` (and set `use_gpu=True` if you have GPUs). If you have a Ray cluster running, just run the script from a node with `ray.init()` auto-connecting.

---

## What this shows

* **Ray Train** runs the train loop on 1+ workers (DDP on GPUs if available).
* **Ray Tune** explores LR/batch size/hidden units/dropout and picks the **best accuracy**.
* **Checkpointing** saves/loads the best model cleanly for inference.

