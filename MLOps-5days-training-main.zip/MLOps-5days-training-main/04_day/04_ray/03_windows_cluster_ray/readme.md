Awesome—let’s wire up a **Ray + FastAPI** POC across your 5 Windows PCs (each with ~4 GB VRAM), where one box runs the FastAPI server and the other machines host lightweight LLM workers for inference.

I’ll give you everything: network prep, installs, Ray cluster bring-up, a tiny CUDA-accelerated LLM per node (llama.cpp), and a FastAPI app that routes requests to Ray actors across the cluster.

---

# 0) What you’ll end up with

* **1× FastAPI head/server node** (Windows)
  Exposes `POST /v1/generate` and dispatches to Ray actors.

* **4× worker nodes** (Windows)
  Each loads a **light LLM** (e.g., TinyLlama 1.1B, GGUF Q4_K_M) on its local GPU via `llama-cpp-python[cuda]`.

* **Ray cluster**
  Head node orchestrates workers; requests are balanced across actors (one actor per GPU).

---

# 1) Prereqs (all machines)

1. **NVIDIA driver + CUDA runtime present**

   * Make sure `nvidia-smi` works (PowerShell):

     ```powershell
     nvidia-smi
     ```
   * CUDA 12.x is ideal for prebuilt `llama-cpp-python[cuda]` wheels.

2. **Python 3.10 or 3.11 (64-bit)**

   * Install from python.org (tick “Add Python to PATH”).

3. **Allow Ray ports in Windows Firewall** (run PowerShell as Admin)

   ```powershell
   New-NetFirewallRule -DisplayName "Ray GCS 6379" -Direction Inbound -Protocol TCP -LocalPort 6379 -Action Allow
   New-NetFirewallRule -DisplayName "Ray Dashboard 8265" -Direction Inbound -Protocol TCP -LocalPort 8265 -Action Allow
   ```

   (That’s enough for a POC on a LAN. Keep machines on the same subnet.)

4. **Create a working folder on each machine**, e.g. `C:\ray_poc`

---

# 2) Install dependencies (all machines)

From PowerShell in `C:\ray_poc`:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1

pip install --upgrade pip
pip install "ray[default]" fastapi uvicorn[standard] pydantic
pip install "llama-cpp-python[cuda]"  # prebuilt CUDA wheel
pip install huggingface_hub
```

Enable CUDA in llama.cpp (persist for future shells):

```powershell
setx LLAMA_CUBLAS 1
```

> If the CUDA wheel fails, you can still run CPU-only by installing `llama-cpp-python` (without `[cuda]`). It will be slower but fine for a POC.

---

# 3) Put a tiny model on each worker (same path on every machine)

We’ll use **TinyLlama-1.1B-Chat** (GGUF, Q4_K_M). On each **worker** machine:

```powershell
.\.venv\Scripts\Activate.ps1
python -c "from huggingface_hub import snapshot_download; snapshot_download('TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF', local_dir='C:\\llm_models\\tinyllama', allow_patterns=['*Q4_K_M.gguf'])"
```

This will place something like:

```
C:\llm_models\tinyllama\TinyLlama-1.1B-Chat-v1.0.Q4_K_M.gguf
```

> Use **the exact same path** on all workers (you can copy the file manually if HF download is slow). With 4 GB VRAM, a 1.1B Q4_K_M will be comfy and fast. You *can* try a 7B Q4 if you want, but 4 GB is tight.

---

# 4) Start the Ray cluster

Pick the **server/head** machine (this will also run FastAPI).

### On the head (server) machine

Find its LAN IP:

```powershell
ipconfig  # note your IPv4, e.g., 192.168.1.50
```

Start the head:

```powershell
.\.venv\Scripts\Activate.ps1
ray stop --force
ray start --head --port=6379 --dashboard-host=0.0.0.0 --dashboard-port=8265
```

### On each worker machine

Replace `HEAD_IP` with the head’s IPv4:

```powershell
.\.venv\Scripts\Activate.ps1
ray stop --force
ray start --address=HEAD_IP:6379
```

> Verify on the head: open `http://HEAD_IP:8265` to see Ray Dashboard (nodes, resources).

---

# 5) Drop in the code (only on the **head/server** machine)

Create `server.py` in `C:\ray_poc`:

```python
import os
import ray
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional

# ---------- Config ----------
MODEL_PATH = r"C:\llm_models\tinyllama\TinyLlama-1.1B-Chat-v1.0.Q4_K_M.gguf"
N_GPU_LAYERS = 50          # tune for your GPU; 40-60 is fine for tiny models on 4GB
CTX_SIZE = 2048
BATCH = 256
SYSTEM_PROMPT = "You are a helpful assistant."

# ---------- Ray Init ----------
# Ship this working dir to workers so they have the code.
ray.init(address="auto", runtime_env={"working_dir": "."})

# ---------- Worker Actor ----------
@ray.remote(num_gpus=1)  # one actor per GPU
class LLMWorker:
    def __init__(self, model_path: str):
        # Lazy import on worker
        from llama_cpp import Llama

        if not os.path.isfile(model_path):
            raise FileNotFoundError(f"Model not found at {model_path}")

        # CUDA is enabled via LLAMA_CUBLAS=1 env var.
        self.llm = Llama(
            model_path=model_path,
            n_ctx=CTX_SIZE,
            n_gpu_layers=N_GPU_LAYERS,   # how many layers to keep on GPU
            n_threads=os.cpu_count(),    # CPU threads for KV/cache work
            n_batch=BATCH,
            verbose=False,
        )

    def generate(self, prompt: str, temperature: float = 0.2, max_tokens: int = 256) -> str:
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]
        out = self.llm.create_chat_completion(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=False,
        )
        return out["choices"][0]["message"]["content"]

# ---------- Create Actor Pool ----------
def create_workers():
    # Count GPUs in the cluster
    total_gpus = int(ray.available_resources().get("GPU", 0))
    if total_gpus == 0:
        raise RuntimeError("Ray sees 0 GPUs. Ensure workers joined and nvidia-smi works.")
    workers = [LLMWorker.remote(MODEL_PATH) for _ in range(total_gpus)]
    # Warm-up (forces model load now)
    ray.get([w.generate.remote("Warm up.") for w in workers])
    return workers

WORKERS = create_workers()
_rr = 0  # round-robin pointer

def next_worker():
    global _rr
    w = WORKERS[_rr]
    _rr = (_rr + 1) % len(WORKERS)
    return w

# ---------- FastAPI ----------
app = FastAPI(title="Ray LLM POC", version="1.0.0")

class GenRequest(BaseModel):
    prompt: str
    temperature: Optional[float] = 0.2
    max_tokens: Optional[int] = 256

@app.get("/health")
def health():
    nodes = ray.nodes()
    return {
        "status": "ok",
        "nodes": len(nodes),
        "workers": len(WORKERS),
        "gpus_seen": int(ray.available_resources().get("GPU", 0)),
    }

@app.post("/v1/generate")
def generate(body: GenRequest):
    worker = next_worker()
    result = ray.get(worker.generate.remote(
        body.prompt,
        temperature=body.temperature,
        max_tokens=body.max_tokens
    ))
    return {"text": result}
```

Run the FastAPI server (still on the head machine):

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn server:app --host 0.0.0.0 --port 8000
```

---

# 6) Test it

From any machine on the LAN (replace `HEAD_IP`):

**Health:**

```powershell
curl http://HEAD_IP:8000/health
```

**Generate:**

```powershell
curl -X POST http://HEAD_IP:8000/v1/generate ^
  -H "Content-Type: application/json" ^
  -d "{""prompt"": ""Explain Ray in one sentence.""}"
```

You should see a short answer. Fire several requests in parallel; Ray will queue & distribute across actors.

---

# 7) Notes, tuning, and common pitfalls

* **Model path must exist on every worker** at the same location (`MODEL_PATH`).
  For POC: copy the GGUF file to each worker. (Network share is OK for *loading*, but local SSD is faster.)

* **If CUDA wheel fails**

  * Use CPU wheel: `pip install llama-cpp-python` and set `N_GPU_LAYERS = 0`.
  * Or ensure CUDA 12.x and retry `pip install "llama-cpp-python[cuda]"`.

* **4 GB VRAM tips**

  * Keep `n_gpu_layers` modest (40–60 for TinyLlama is fine).
  * Stick to **1–3B** models in Q4 for good speed. (1.1B is snappy; 3B also OK; 7B Q4 may OOM.)

* **Scaling replicas**

  * Ray schedules 1 actor per GPU via `@ray.remote(num_gpus=1)`. If a worker has no GPU, set up CPU actors separately.

* **Ray can ship your code** using `runtime_env={"working_dir": "."}`—you don’t need to copy `server.py` to workers.

* **Firewall / connectivity**

  * If workers can’t join, recheck the head IP and port 6379; confirm you can ping the head.

* **Security**

  * Keep this on a private LAN. Don’t expose 6379/8265/8000 to the internet.

* **Optional: Ray Dashboard**

  * Visit `http://HEAD_IP:8265` to watch actors, tasks, and resource usage live.

---

# 8) Optional: CPU-only fallback worker (if a PC lacks a GPU)

Change the worker decorator and init:

```python
@ray.remote(num_cpus=1)  # instead of num_gpus=1
class LLMWorker:
    def __init__(...):
        from llama_cpp import Llama
        self.llm = Llama(
            model_path=model_path,
            n_ctx=CTX_SIZE,
            n_gpu_layers=0,   # force CPU
            n_threads=os.cpu_count(),
            n_batch=64,
        )
```

You can mix GPU and CPU actors in the same cluster (the round-robin will treat them equally; GPU replies will just be faster).

---

# 9) Optional: try a slightly larger/smarter model

* **Phi-2** GGUF (2.7B) or **Qwen2.5-1.5B-Instruct** GGUF run nicely on 4 GB with Q4. Just swap `MODEL_PATH`.

---

That’s it. Follow the steps and you’ll have a working distributed inference POC: one FastAPI endpoint fronting multiple Windows GPU boxes via Ray. If you want, I can also give you a **Docker/WSL2** version or a **Ray Serve** variant that embeds the HTTP layer directly into Ray—but your current requirement (“one FastAPI server, multiple Ray workers”) is exactly what the above implements.
