import asyncio
from typing import List, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import ray
from ray.util.scheduling_strategies import NodeAffinitySchedulingStrategy

from .slm_actor import SLMActor

app = FastAPI(title="Distributed SLM over Ray (Single FastAPI Front)")

ACTORS: List[ray.actor.ActorHandle] = []
ROUND_ROBIN_IDX: int = 0

class GenRequest(BaseModel):
    prompt: str
    max_new_tokens: int = 50
    temperature: float = 0.8
    top_k: int = 50
    top_p: float = 0.95

class GenResponse(BaseModel):
    node_ip: str
    text: str

def _connect_ray():
    if not ray.is_initialized():
        ray.init(address="auto", ignore_reinit_error=True, logging_level="WARNING")

async def _ensure_actors():
    global ACTORS
    if ACTORS:
        return

    nodes = [n for n in ray.nodes() if n.get("Alive")]
    created = []
    used_node_ids = set()
    for n in nodes:
        node_id = n.get("NodeID")
        if node_id in used_node_ids:
            continue
        try:
            actor = SLMActor.options(
                scheduling_strategy=NodeAffinitySchedulingStrategy(node_id=node_id, soft=False),
                lifetime="detached"
            ).remote()
            ray.get(actor.ping.remote())
            created.append(actor)
            used_node_ids.add(node_id)
            if len(created) == 2:
                break
        except Exception:
            actor = SLMActor.options().remote()
            ray.get(actor.ping.remote())
            created.append(actor)
            if len(created) == 2:
                break

    if not created:
        created = [SLMActor.options().remote()]
        ray.get(created[0].ping.remote())

    ACTORS = created

@app.on_event("startup")
async def startup_event():
    _connect_ray()
    await _ensure_actors()

@app.get("/healthz")
async def health() -> Dict[str, Any]:
    _connect_ray()
    await _ensure_actors()
    nodes = [n for n in ray.nodes() if n.get("Alive")]
    return {
        "ray_connected": True,
        "alive_nodes": len(nodes),
        "actors": len(ACTORS),
        "node_ips": [n["NodeManagerAddress"] for n in nodes],
    }

@app.post("/generate", response_model=GenResponse)
async def generate(req: GenRequest) -> GenResponse:
    global ROUND_ROBIN_IDX
    _connect_ray()
    await _ensure_actors()
    if not ACTORS:
        raise HTTPException(status_code=500, detail="No SLM actors available")

    actor = ACTORS[ROUND_ROBIN_IDX % len(ACTORS)]
    ROUND_ROBIN_IDX += 1

    try:
        text, node_ip = ray.get(actor.generate.remote(
            req.prompt,
            max_new_tokens=req.max_new_tokens,
            temperature=req.temperature,
            top_k=req.top_k,
            top_p=req.top_p
        ))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Inference failed: {e}")

    return GenResponse(node_ip=node_ip, text=text)
