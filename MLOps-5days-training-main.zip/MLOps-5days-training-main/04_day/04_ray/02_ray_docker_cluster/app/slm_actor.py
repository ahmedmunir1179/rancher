import os
import socket
from typing import Tuple
import ray

@ray.remote
class SLMActor:
    def __init__(self):
        from transformers import pipeline
        model_name = os.environ.get("SLM_MODEL", "distilgpt2")
        self.generator = pipeline("text-generation", model=model_name)
        self.node_ip = socket.gethostbyname(socket.gethostname())

    def ping(self) -> str:
        return f"SLMActor alive on {self.node_ip}"

    def generate(self, prompt: str, max_new_tokens: int = 50, temperature: float = 0.8, top_k: int = 50, top_p: float = 0.95) -> Tuple[str, str]:
        outputs = self.generator(
            prompt,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            num_return_sequences=1,
            pad_token_id=50256
        )
        text = outputs[0]["generated_text"]
        return text, self.node_ip
