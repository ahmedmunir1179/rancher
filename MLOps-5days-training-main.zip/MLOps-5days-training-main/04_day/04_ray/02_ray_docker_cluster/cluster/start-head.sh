#!/usr/bin/env bash
set -euo pipefail

ray start --head --port=${RAY_HEAD_PORT:-6379} --dashboard-host=0.0.0.0

echo "[ray-head] Waiting a bit for workers to join..."
sleep 5

exec uvicorn app.main:app --host ${UVICORN_HOST:-0.0.0.0} --port ${UVICORN_PORT:-8000} --workers 1
