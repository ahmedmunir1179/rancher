#!/usr/bin/env bash
set -euo pipefail

ray start --address=${RAY_HEAD_SERVICE_HOST:-ray-head}:${RAY_HEAD_PORT:-6379}

tail -f /dev/null
