# PoC: One FastAPI Front, SLM loaded on multiple machines via Ray

This proof‑of‑concept spins up a **Ray cluster across two worker containers** and a **single FastAPI server** on the head node. The FastAPI server creates one SLM actor **on each worker** so the same small language model (SLM) is loaded in **two different machines** but exposed through **one HTTP endpoint**.

## What you get

- `ray-head` container: runs **Ray head + FastAPI**
- `ray-worker-1` and `ray-worker-2`: join the cluster as Ray workers
- On startup, FastAPI connects to Ray and creates **one `SLMActor` per node** (affinity), each loading a tiny CPU-friendly model (`distilgpt2`).
- A single `/generate` endpoint does **round-robin** across both actors.

## Quick start

```bash
docker compose up --build
```

Then:
- Ray dashboard: http://localhost:8265
- FastAPI health: http://localhost:8000/healthz


### Test generation

```bash
curl -X POST http://localhost:8000/generate   -H "Content-Type: application/json"   -d '{"prompt": "In a world of distributed systems,", "max_new_tokens": 40}'
```

You will see JSON like:
```json
{
  "node_ip": "172.22.0.3",
  "text": "In a world of distributed systems, ..."
}
```
Subsequent calls will alternate `node_ip` between the two worker containers.

## Project layout

```
ray-slm-fastapi-poc/
├─ app/
│  ├─ main.py          # FastAPI server: connects to Ray, creates per-node actors, routes requests
│  └─ slm_actor.py     # Ray @remote actor that loads a tiny SLM and runs generation
├─ cluster/
│  ├─ start-head.sh    # Starts ray head and uvicorn
│  └─ start-worker.sh  # Starts ray worker and tails to stay alive
├─ Dockerfile
├─ docker-compose.yml
├─ requirements.txt
└─ README.md
```

## Notes & tweaks

- Change model: set env var `SLM_MODEL` to any small HF model available in `transformers`.
- GPU (optional): if you run on GPU machines, set `USE_ACCELERATE=1` and mount CUDA; the actor uses a HF pipeline that can place on GPU if available.
- Scaling: add more worker services to `docker-compose.yml`; FastAPI will create an actor per alive node.
- Strategy: we use `NodeAffinitySchedulingStrategy` to place one actor per distinct node.
- Single front‑end: regardless of how many workers exist, **only one FastAPI server** is exposed.

## Troubleshooting

- If `/healthz` shows fewer than 3 nodes (1 head + 2 workers), ensure workers can resolve `ray-head:6379`.
- First startup downloads the HF model (internet required). For offline, bake the model into the image or use local cache volumes.
- If memory is tight, use even tinier models or reduce `max_new_tokens`.
<img width="2294" height="1198" alt="image" src="https://github.com/user-attachments/assets/113f5a63-3632-4a4c-8d3f-05e923484c00" />

